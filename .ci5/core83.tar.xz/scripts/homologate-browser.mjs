import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
import { chromium } from 'playwright';
import { canonicalFromLegacy, validateLegacyPayload } from '../src/data/legacy-compat.js';
import { auditCanonical, financialSignatures, compareFinancialSignatures } from '../src/data/integrity.js';

const [snapshotPath='homologation/fixtures/external-smoke-backup.json', outputJson='homologation/external-results/browser.json', outputMd='homologation/external-results/browser.md'] = process.argv.slice(2);
const baseUrl=process.env.OFICINAOS_BASE_URL || 'http://127.0.0.1:4173/';
const rawBytes=await fs.readFile(snapshotPath);const raw=JSON.parse(rawBytes.toString('utf8'));
const validation=validateLegacyPayload(raw);if(!validation.valid)throw new Error('Snapshot não reconhecido pelo importador OficinaOS.');
const expected=canonicalFromLegacy(raw);const expectedAudit=auditCanonical(expected);const expectedFinancial=financialSignatures(expected);
function stable(v){if(Array.isArray(v))return v.map(stable);if(v&&typeof v==='object'){const o={};for(const k of Object.keys(v).sort())o[k]=stable(v[k]);return o;}return v??null;}
function digest(v){return crypto.createHash('sha256').update(JSON.stringify(stable(v))).digest('hex');}
function sorted(list=[]){return [...list].sort((a,b)=>String(a?.id??'').localeCompare(String(b?.id??'')));}
function hashes(s){return Object.fromEntries(['transactions','accounts','jobs','clients','workOrders','appointments','checklists','budgets','goals'].map(k=>[k,digest(sorted(s[k]||[]))]));}
const expectedHashes=hashes(expected);
const evidence={generatedAt:new Date().toISOString(),baseUrl,snapshot:{path:path.resolve(snapshotPath),sha256:crypto.createHash('sha256').update(rawBytes).digest('hex'),synthetic:!!raw.homologationFixture?.synthetic},gates:{},consoleErrors:[],pageErrors:[],result:{pass:true}};
const gate=(name,pass,detail)=>{evidence.gates[name]={pass:!!pass,detail};if(!pass)evidence.result.pass=false;};

const browser=await chromium.launch({headless:true});
const context=await browser.newContext({acceptDownloads:true});
const page=await context.newPage();
page.on('console',msg=>{if(msg.type()==='error')evidence.consoleErrors.push(msg.text());});
page.on('pageerror',err=>evidence.pageErrors.push(err.message));
page.on('dialog',dialog=>dialog.accept());
await page.addInitScript(()=>{window.__OFIX_PRINT_CALLS__=0;window.print=()=>{window.__OFIX_PRINT_CALLS__+=1;};window.open=(...args)=>{window.__OFIX_WINDOW_OPEN__=args;return null;};});

async function dbSnapshot(){
  return await page.evaluate(async()=>{
    const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('oficinaos_modular');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
    const names=[...db.objectStoreNames];const out={};
    await Promise.all(names.map(name=>new Promise((resolve,reject)=>{const tx=db.transaction(name,'readonly');const req=tx.objectStore(name).getAll();req.onsuccess=()=>{out[name]=req.result;resolve();};req.onerror=()=>reject(req.error);})));db.close();return out;
  });
}
async function clearDb(){await page.evaluate(async()=>{await new Promise((resolve,reject)=>{const r=indexedDB.deleteDatabase('oficinaos_modular');r.onsuccess=()=>resolve();r.onerror=()=>reject(r.error);r.onblocked=()=>resolve();});});}
function browserHashes(s){return hashes(s);}

try{
  await page.goto(baseUrl,{waitUntil:'networkidle',timeout:60000});
  await page.getByText('OficinaOS',{exact:true}).waitFor({state:'visible'});
  gate('pageLoads',true,'shell OficinaOS carregado');
  const dupIds=await page.evaluate(()=>{const seen=new Set(),dups=[];for(const n of document.querySelectorAll('[id]')){if(seen.has(n.id))dups.push(n.id);seen.add(n.id);}return [...new Set(dups)];});
  gate('noDuplicateHtmlIds',dupIds.length===0,dupIds.length?dupIds.join(', '):'0 IDs duplicados');

  await clearDb();await page.reload({waitUntil:'networkidle'});
  const chooserPromise=page.waitForEvent('filechooser');
  await page.getByRole('button',{name:'Importar backup JSON'}).click();
  const chooser=await chooserPromise;await chooser.setFiles(snapshotPath);
  await page.locator('.status-line').filter({hasText:'Backup importado'}).waitFor({timeout:60000});
  const afterImport=await dbSnapshot();
  const importAudit=auditCanonical(afterImport);const importHashes=browserHashes(afterImport);const importFinancial=financialSignatures(afterImport);
  const criticalDiff=Object.keys(expectedHashes).filter(k=>expectedHashes[k]!==importHashes[k]);
  const finCmp=compareFinancialSignatures(expectedFinancial,importFinancial);
  gate('indexedDbImportCounts',Object.entries(expectedAudit.counts).every(([k,v])=>(importAudit.counts[k]??0)===v),'contagens IndexedDB após importação comparadas ao snapshot');
  gate('indexedDbImportCriticalHashes',criticalDiff.length===0,criticalDiff.length?`diferenças: ${criticalDiff.join(', ')}`:'hashes críticos idênticos');
  gate('indexedDbFinancialSignatures',finCmp.equal,finCmp.equal?'assinaturas Financeiro/Contas idênticas':finCmp.differences.join(', '));

  await page.reload({waitUntil:'networkidle'});const afterReload=await dbSnapshot();const reloadHashes=browserHashes(afterReload);const reloadDiff=Object.keys(importHashes).filter(k=>importHashes[k]!==reloadHashes[k]);
  gate('indexedDbReloadPersistence',reloadDiff.length===0,reloadDiff.length?`stores divergentes: ${reloadDiff.join(', ')}`:'persistência exata após reload');

  const navLabels=['Orçamento','Financeiro','Contas','Clientes','Categorias','Estoque','Metas','Configurações','Agenda','OS','Históricos','Relatórios','Consultor IA'];
  for(const label of navLabels){await page.getByRole('button',{name:label,exact:true}).click();await page.waitForTimeout(60);}
  gate('moduleNavigation',true,`${navLabels.length} módulos navegados`);

  await page.getByRole('button',{name:'Orçamento',exact:true}).click();
  const firstBudget=page.locator('.budget-history-open').first();
  if(await firstBudget.count()){await firstBudget.click();await page.getByRole('button',{name:'PDF comercial',exact:true}).click();await page.locator('.commercial-print-sheet').waitFor({state:'visible'});const quoteText=(await page.locator('.commercial-print-sheet').innerText()).toLowerCase();const forbidden=['segredo interno','r$ / hora','margem','custo interno','observações internas'];const leaked=forbidden.filter(k=>quoteText.includes(k));const printCalls=await page.evaluate(()=>window.__OFIX_PRINT_CALLS__||0);gate('commercialPdfBrowserPrivacy',leaked.length===0&&printCalls===1,leaked.length?`vazamentos: ${leaked.join(', ')}`:`print chamado ${printCalls}x e sem campos internos`);}else gate('commercialPdfBrowserPrivacy',false,'nenhum orçamento encontrado após importação');

  await page.getByRole('button',{name:'Migração',exact:true}).click();
  const downloadPromise=page.waitForEvent('download');await page.getByRole('button',{name:'Exportar backup compatível'}).click();const download=await downloadPromise;const exportPath=path.resolve('homologation/external-results/exported-browser-backup.json');await fs.mkdir(path.dirname(exportPath),{recursive:true});await download.saveAs(exportPath);const exported=JSON.parse(await fs.readFile(exportPath,'utf8'));const round=canonicalFromLegacy(exported);const roundHashes=hashes(round);const roundDiff=Object.keys(importHashes).filter(k=>importHashes[k]!==roundHashes[k]);gate('browserExportRoundTrip',roundDiff.length===0,roundDiff.length?`stores divergentes: ${roundDiff.join(', ')}`:'exportação UI preserva hashes críticos');evidence.artifacts={exportedBackup:exportPath};

  gate('noPageErrors',evidence.pageErrors.length===0,evidence.pageErrors.length?evidence.pageErrors.join(' | '):'0 page errors');
  gate('noConsoleErrors',evidence.consoleErrors.length===0,evidence.consoleErrors.length?evidence.consoleErrors.join(' | '):'0 console errors');
}catch(error){evidence.result.pass=false;evidence.result.error={name:error.name,message:error.message,stack:error.stack};}
finally{await browser.close();}

const lines=['# Homologação Externa — Browser/IndexedDB','',`Gerado em: ${evidence.generatedAt}`,`Snapshot: \`${evidence.snapshot.path}\``,`Sintético CLEAN: **${evidence.snapshot.synthetic?'SIM':'NÃO'}**`,'',`Resultado: **${evidence.result.pass?'PASS':'FAIL'}**`,'','## Gates',''];for(const [n,g] of Object.entries(evidence.gates))lines.push(`- ${n}: **${g.pass?'OK':'FALHOU'}** — ${g.detail}`);if(evidence.result.error)lines.push('','## Erro','',`[0m${evidence.result.error.name}: ${evidence.result.error.message}`);lines.push('','## Limite','','Um PASS com fixture sintética prova build/browser/IndexedDB/UI/reload/PDF/exportação no ambiente externo, mas não substitui o gate de contagens do snapshot oficial.');
await fs.mkdir(path.dirname(outputJson),{recursive:true});await fs.writeFile(outputJson,JSON.stringify(evidence,null,2)+'\n');await fs.writeFile(outputMd,lines.join('\n')+'\n');console.log(JSON.stringify(evidence,null,2));if(!evidence.result.pass)process.exitCode=1;
