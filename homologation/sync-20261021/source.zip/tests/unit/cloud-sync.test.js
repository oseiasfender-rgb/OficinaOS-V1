import test from 'node:test';
import assert from 'node:assert/strict';
import {createSyncEngine,snapshotIdentity,SyncConflict} from '../../src/data/cloud/sync-engine.js';
import {createSupabaseTransport} from '../../src/data/cloud/supabase-transport.js';

const snapshot = (value=0)=>({schema:'oficinaos-modular-v5',stores:{budgets:[{id:'q1',total:value,optional:null}]}});
function fixture(){
  const heads=new Map(),operations=new Map(),copies=[];let failAfterWrite=false;
  const remote={read:async({namespace})=>structuredClone(heads.get(namespace)??null),commit:async x=>{
    if(operations.has(x.operationId))return operations.get(x.operationId);
    const rev=heads.get(x.namespace)?.revision??0;if(rev!==x.baseRevision)throw new SyncConflict();
    const result={revision:rev+1};heads.set(x.namespace,{revision:rev+1,payload:structuredClone(x.payload)});operations.set(x.operationId,result);
    if(failAfterWrite){failAfterWrite=false;throw Error('network timeout');}return result;
  }};
  function device(value=0,user='owner',namespace='homologacao'){
    let data=snapshot(value),allow=true;const values=new Map();const backups=[];let backupHook;
    const metadata={get:async k=>structuredClone(values.get(k)),set:async(k,v)=>values.set(k,structuredClone(v))};
    const local={read:async()=>structuredClone(data),withLock:fn=>fn(),canApply:async()=>allow,backup:async s=>{backups.push(structuredClone(s));await backupHook?.();},apply:async(s,expected)=>{assert.equal(snapshotIdentity(data),expected);data=structuredClone(s);}};
    const engine=createSyncEngine({local,remote,metadata,userId:user,namespace,uuid:()=>crypto.randomUUID()});
    return {engine,local,metadata,values,backups,set:n=>{data=snapshot(n);},get:()=>data,allow:n=>{allow=n;},onBackup:fn=>{backupHook=fn;}};
  }
  return {remote,device,heads,operations,copies,failNext:()=>{failAfterWrite=true;}};
}

test('Primeiro acesso nunca publica nem substitui dados automaticamente',async()=>{
  const f=fixture(),d=f.device(100);assert.equal((await d.engine.tick()).status,'initial-choice-required');assert.equal(f.heads.size,0);assert.equal(d.get().stores.budgets[0].total,100);
});
test('Publicação inicial explícita e sincronização de outro aparelho preservam cópia local',async()=>{
  const f=fixture(),pc=f.device(100),phone=f.device(10);
  await pc.engine.enrollFromLocal();await phone.engine.enrollFromCloud();assert.equal(phone.get().stores.budgets[0].total,100);assert.equal(phone.backups[0].stores.budgets[0].total,10);
  pc.set(200);assert.equal((await pc.engine.tick()).status,'uploaded');assert.equal((await phone.engine.tick()).status,'downloaded');assert.equal(phone.get().stores.budgets[0].total,200);
});
test('PC e celular divergentes bloqueiam sobrescrita e preservam ambos',async()=>{
  const f=fixture(),pc=f.device(100),phone=f.device();await pc.engine.enrollFromLocal();await phone.engine.enrollFromCloud();pc.set(150);phone.set(170);await pc.engine.tick();assert.equal((await phone.engine.tick()).status,'conflict');assert.equal(phone.get().stores.budgets[0].total,170);assert.equal(f.heads.get('homologacao').payload.stores.budgets[0].total,150);
});
test('Reenvio após timeout não duplica revisão na nuvem',async()=>{
  const f=fixture(),pc=f.device(100);await pc.engine.enrollFromLocal();pc.set(200);f.failNext();await assert.rejects(pc.engine.tick(),/timeout/);assert.equal((await pc.engine.tick()).status,'synced');assert.equal(f.heads.get('homologacao').revision,2);assert.equal(f.operations.size,2);
});
test('Falha na primeira publicação permite recuperar o envio aceito',async()=>{
  const f=fixture(),pc=f.device(100);f.failNext();await assert.rejects(pc.engine.enrollFromLocal());assert.equal((await pc.engine.tick()).status,'synced');assert.equal(f.heads.get('homologacao').revision,1);
});
test('Publicação inicial recusa substituir nuvem existente',async()=>{
  const f=fixture(),pc=f.device(100),phone=f.device(200);await pc.engine.enrollFromLocal();await assert.rejects(phone.engine.enrollFromLocal(),SyncConflict);assert.equal(f.heads.get('homologacao').payload.stores.budgets[0].total,100);
});
test('Editor ocupado impede recebimento sem perder a alteração remota',async()=>{
  const f=fixture(),pc=f.device(100),phone=f.device();await pc.engine.enrollFromLocal();await phone.engine.enrollFromCloud();pc.set(200);await pc.engine.tick();phone.allow(false);assert.equal((await phone.engine.tick()).status,'waiting-for-editor');assert.equal(phone.get().stores.budgets[0].total,100);phone.allow(true);assert.equal((await phone.engine.tick()).status,'downloaded');
});
test('Gravação local durante backup cancela substituição remota',async()=>{
  const f=fixture(),pc=f.device(100),phone=f.device();await pc.engine.enrollFromLocal();await phone.engine.enrollFromCloud();pc.set(200);await pc.engine.tick();phone.onBackup(()=>phone.set(300));assert.equal((await phone.engine.tick()).status,'waiting-for-local-write');assert.equal(phone.get().stores.budgets[0].total,300);
});
test('Ambientes e identidades de conta mantêm metadados separados',async()=>{
  const f=fixture(),pc=f.device(100,'owner','homologacao'),prod=f.device(200,'owner','producao');await pc.engine.enrollFromLocal();await prod.engine.enrollFromLocal();assert.equal(f.heads.size,2);assert.deepEqual([...pc.values.keys()],['owner:homologacao']);assert.deepEqual([...prod.values.keys()],['owner:producao']);
});
test('Ordem dos registros não cria alteração; zero e ausência continuam diferentes',()=>{
  const a={schema:'s',stores:{x:[{id:2,value:0},{id:1,value:null}]}};
  assert.equal(snapshotIdentity(a),snapshotIdentity({schema:'s',stores:{x:[{value:null,id:1},{value:0,id:2}]}}));
  assert.notEqual(snapshotIdentity(snapshot(0)),snapshotIdentity(snapshot(null)));assert.throws(()=>snapshotIdentity({stores:{x:[{id:1},{id:1}]}}),/duplicada/);
});
test('Revisão remota retrocedida não altera dados',async()=>{
  const f=fixture(),pc=f.device(100);await pc.engine.enrollFromLocal();f.heads.get('homologacao').revision=0;await assert.rejects(pc.engine.tick(),/retrocedida/);assert.equal(pc.get().stores.budgets[0].total,100);
});
test('Transporte rejeita chave secreta e URL fora do projeto Supabase',()=>{
  const cfg={url:'https://example.supabase.co',publishableKey:'sb_publishable_test',getSession:async()=>null};
  assert.throws(()=>createSupabaseTransport({...cfg,publishableKey:'sb_secret_private'}));assert.throws(()=>createSupabaseTransport({...cfg,url:'http://example.supabase.co'}));assert.throws(()=>createSupabaseTransport({...cfg,url:'https://evil.example/'}));
});
test('Transporte sem login não faz requisição; conflito HTTP preserva significado',async()=>{
  let called=false;const cfg={url:'https://example.supabase.co',publishableKey:'sb_publishable_test',getSession:async()=>null,fetchImpl:async()=>{called=true;}};
  await assert.rejects(createSupabaseTransport(cfg).read({namespace:'homologacao'}),/Entre/);assert.equal(called,false);
  const driver=createSupabaseTransport({...cfg,getSession:async()=>({access_token:'session'}),fetchImpl:async()=>({ok:false,status:400,json:async()=>({code:'40001'})})});await assert.rejects(driver.commit({namespace:'homologacao'}),SyncConflict);
});
