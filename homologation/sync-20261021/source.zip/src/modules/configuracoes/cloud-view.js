import {el,button,labeledField} from '../../ui/dom.js';
import {downloadJson} from '../../data/backup-service.js';

export function renderCloudSettings(host,cloud){
  const card=el('section','module-card cloud-settings');card.append(el('h2','','☁️ Sincronização e cópias na nuvem'));
  const status=el('p','module-feedback');status.setAttribute('role','status');
  const help=el('p','muted-small','Entre com o mesmo acesso da oficina no PC e no celular. Dados desta homologação ficam separados da produção.');
  const form=el('form','config-form');const email=el('input','mod-input'),password=el('input','mod-input');email.type='email';email.autocomplete='username';password.type='password';password.autocomplete='current-password';password.minLength=8;email.required=password.required=true;
  const login=button('Entrar','btn btn-primary','submit'),register=button('Criar acesso','btn');form.append(labeledField('E-mail de acesso à nuvem',email),labeledField('Senha de acesso à nuvem',password),login,register);
  const actions=el('div','budget-action-grid');
  const send=button('Usar este aparelho como origem','btn'),receive=button('Receber dados da nuvem','btn'),sync=button('Sincronizar agora','btn'),pause=button('Pausar sincronização','btn'),signout=button('Sair neste aparelho','btn'),versions=button('Consultar cópias na nuvem','btn'),localCopies=button('Cópias locais preventivas','btn');
  actions.append(send,receive,sync,pause,signout,versions,localCopies);const copies=el('div','cloud-copies');
  card.append(help,status,form,actions,el('p','muted-small','Após ativar: sincroniza dados salvos a cada 30 segundos, com o aplicativo aberto e conectado. Alterações divergentes pedem revisão. Cada envio aceito cria uma cópia versionada. Limites desta integração: 8 MiB por envio e 64 MiB de cópias por conta; ao atingir o limite, o envio para e avisa. As cópias ficam no mesmo projeto Supabase e não substituem uma cópia externa. Nenhum backup é apagado automaticamente.'),copies);host.append(card);
  let unsubscribe;
  const messages={'signed-out':'Entre para configurar a nuvem.','disabled':'Sincronização pausada neste aparelho.','ready':'Pronto para sincronizar.','initial-choice-required':'Escolha o aparelho de origem ou receba a cópia da nuvem.','synced':'Dados salvos sincronizados.','uploaded':'Dados enviados e cópia versionada criada.','downloaded':'Dados da nuvem recebidos.','conflict':'PC e celular têm alterações diferentes. Nada foi sobrescrito. Exporte as duas cópias antes de escolher qual usar.','waiting-for-editor':'Há dados novos na nuvem. Receba-os depois de salvar o formulário.','waiting-for-local-write':'Dados locais mudaram. A sincronização será tentada novamente.','error':'Não foi possível sincronizar.'};
  unsubscribe=cloud.subscribe(s=>{
    status.textContent=[messages[s.phase]??s.phase,s.email,s.lastSync?`Última sincronização: ${new Date(s.lastSync).toLocaleString('pt-BR')}`:'',s.lastError].filter(Boolean).join(' · ');
    form.hidden=!!s.email;actions.hidden=!s.email;
    for(const b of card.querySelectorAll('button'))b.disabled=s.busy;
  });
  async function run(fn){try{await fn();}catch(e){status.textContent=e.message;}}
  form.addEventListener('submit',e=>{e.preventDefault();const secret=password.value;password.value='';run(()=>cloud.signIn(email.value.trim(),secret));});
  register.addEventListener('click',()=>{if(!form.reportValidity())return;const secret=password.value;password.value='';run(async()=>{const r=await cloud.register(email.value.trim(),secret);if(r.confirmationRequired)status.textContent='Acesso solicitado. Confirme o e-mail recebido e volte para entrar com a senha. Não é a senha do GitHub.';});});
  send.addEventListener('click',()=>run(async()=>{if(!window.confirm('Publicar os dados salvos deste aparelho no projeto privado da oficina? Isso inicia a sincronização e o backup na nuvem. Só é permitido quando ainda não há uma cópia remota.'))return;await cloud.activate('send');}));
  receive.addEventListener('click',()=>run(async()=>{if(!window.confirm('Receber a cópia da nuvem e substituir os dados salvos deste aparelho? Uma cópia local preventiva será guardada. Alterações ainda não salvas no formulário serão descartadas.'))return;await cloud.activate('receive');}));
  sync.addEventListener('click',()=>run(()=>cloud.tick()));pause.addEventListener('click',()=>run(()=>cloud.pause()));signout.addEventListener('click',()=>run(()=>cloud.signOut()));
  versions.addEventListener('click',()=>run(async()=>{const rows=await cloud.listVersions();copies.replaceChildren(el('h3','','Cópias versionadas na nuvem'));if(!rows.length)copies.append(el('p','','Nenhuma cópia enviada.'));for(const r of rows){const row=el('div','cloud-copy-row',`Revisão ${r.revision} · ${new Date(r.created_at).toLocaleString('pt-BR')}`),download=button('Baixar JSON','btn btn-small');download.addEventListener('click',()=>run(async()=>downloadJson(await cloud.downloadVersion(r.revision),`OficinaOS-nuvem-revisao-${r.revision}.json`)));row.append(download);copies.append(row);}}));
  localCopies.addEventListener('click',()=>run(async()=>{const rows=await cloud.localBackups();copies.replaceChildren(el('h3','','Cópias preventivas deste aparelho'));if(!rows.length)copies.append(el('p','','Nenhuma cópia preventiva.'));for(const r of rows){const row=el('div','cloud-copy-row',new Date(r.createdAt).toLocaleString('pt-BR')),download=button('Baixar JSON','btn btn-small');download.addEventListener('click',()=>run(async()=>downloadJson(await cloud.readLocalBackup(r.id),`OficinaOS-copia-local-${r.id}.json`)));row.append(download);copies.append(row);}}));
  return {dispose:()=>unsubscribe?.()};
}
