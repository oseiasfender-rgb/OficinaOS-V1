// Synchronizes complete, consistent database snapshots. Divergent snapshots
// require review instead of silently merging financial or workflow records.
export class SyncConflict extends Error {
  constructor(message = 'PC e celular têm alterações diferentes. Ambas foram preservadas.') {
    super(message); this.name = 'SyncConflict';
  }
}

function stable(value) {
  if (Array.isArray(value)) return '[' + value.map(stable).join(',') + ']';
  if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(k => JSON.stringify(k)+':'+stable(value[k])).join(',') + '}';
  return JSON.stringify(value);
}

export function snapshotIdentity(snapshot) {
  if (!snapshot || typeof snapshot !== 'object' || !snapshot.stores || Array.isArray(snapshot.stores)) throw Error('Cópia inválida.');
  const stores = {};
  for (const [name, rows] of Object.entries(snapshot.stores)) {
    if (!Array.isArray(rows)) throw Error(`Coleção inválida: ${name}`);
    const seen = new Set();
    stores[name] = rows.map(row => {
      if (!row || !['string','number'].includes(typeof row.id) || String(row.id).trim() === '') throw Error(`Registro sem identidade em ${name}.`);
      const key = typeof row.id + ':' + row.id;
      if (seen.has(key)) throw Error(`Identidade duplicada em ${name}.`);
      seen.add(key); return row;
    }).sort((a,b) => (typeof a.id+':'+a.id).localeCompare(typeof b.id+':'+b.id));
  }
  return stable({schema:snapshot.schema,stores});
}

export function createSyncEngine({local, remote, metadata, userId, namespace, uuid = () => crypto.randomUUID(), onState = () => {}}) {
  if (!userId || !['homologacao','producao'].includes(namespace)) throw Error('Conta e ambiente de sincronização são obrigatórios.');
  const key = `${userId}:${namespace}`;
  let running = false;
  async function tick() {
    if (running) return {status:'busy'};
    running = true;
    try {
      // The local adapter must enforce a cross-tab lock during read/apply.
      return await local.withLock(async () => {
        const current = await local.read(); const identity = snapshotIdentity(current);
        const saved = await metadata.get(key);
        const cloud = await remote.read({namespace});
        if (!saved) {
          // Never treat the first device's existing data as an empty baseline.
          const identical = cloud && snapshotIdentity(cloud.payload) === identity;
          if (identical) {
            await metadata.set(key,{revision:cloud.revision,identity});
            return report('synced',cloud.revision);
          }
          return report('initial-choice-required');
        }
        if (!cloud && saved.revision > 0) throw Error('A base remota desapareceu. Nenhum dado local foi substituído.');
        const localChanged = identity !== saved.identity || saved.pending?.identity === identity;
        const remoteRevision = cloud?.revision ?? 0;
        if (!Number.isSafeInteger(remoteRevision) || remoteRevision < saved.revision) throw Error('Revisão remota inválida ou retrocedida.');
        if (remoteRevision !== saved.revision) {
          const incoming = snapshotIdentity(cloud.payload);
          if (incoming === identity) {
            await metadata.set(key,{revision:remoteRevision,identity});
            return report('synced',remoteRevision);
          }
          if (localChanged) return report('conflict');
          if (!await local.canApply()) return report('waiting-for-editor');
          await local.backup(current,{reason:'before-cloud-apply'});
          // Guard against writes that arrived while the backup was persisted.
          if (snapshotIdentity(await local.read()) !== identity) return report('waiting-for-local-write');
          await local.apply(cloud.payload,identity); // atomic adapter operation
          await metadata.set(key,{revision:remoteRevision,identity:incoming});
          return report('downloaded',remoteRevision);
        }
        if (!localChanged) return report('synced',remoteRevision);
        const pending = saved.pending?.identity === identity ? saved.pending : {id:uuid(),identity};
        await metadata.set(key,{...saved,pending});
        const result = await remote.commit({namespace,baseRevision:saved.revision,operationId:pending.id,payload:current});
        if (!Number.isSafeInteger(result.revision) || result.revision !== saved.revision+1) throw Error('Confirmação remota inválida.');
        await metadata.set(key,{revision:result.revision,identity});
        return report('uploaded',result.revision);
      });
    } catch (error) {
      if (error instanceof SyncConflict) return report('conflict');
      onState({status:'error',message:error.message}); throw error;
    } finally { running = false; }
  }
  function report(status,revision) { const result={status,...(revision===undefined?{}:{revision})};onState(result);return result; }
  // Explicit initial enrollment after the user chooses the source device.
  async function enrollFromLocal() {
    return local.withLock(async()=>{
      const current=await local.read(); const identity=snapshotIdentity(current);
      if(await remote.read({namespace})) throw new SyncConflict('Já existem dados na nuvem. A primeira publicação não pode substituí-los.');
      // Pending operation survives a timeout immediately after server commit.
      const old=await metadata.get(key);
      const pending=old?.pending?.identity===identity?old.pending:{id:uuid(),identity};
      await metadata.set(key,{revision:0,identity,pending});
      const result=await remote.commit({namespace,baseRevision:0,operationId:pending.id,payload:current});
      if(result.revision!==1)throw Error('Primeira revisão remota inválida.');
      await metadata.set(key,{revision:1,identity});return report('uploaded',1);
    });
  }
  async function enrollFromCloud() {
    return local.withLock(async()=>{
      const cloud=await remote.read({namespace});
      if(!cloud)throw Error('Ainda não há dados na nuvem. Publique primeiro pelo aparelho de origem.');
      const incoming=snapshotIdentity(cloud.payload), current=await local.read();
      const identity=snapshotIdentity(current);
      await local.backup(current,{reason:'before-explicit-cloud-receive'});
      await local.apply(cloud.payload,identity);
      await metadata.set(key,{revision:cloud.revision,identity:incoming});return report('downloaded',cloud.revision);
    });
  }
  return Object.freeze({tick,enrollFromLocal,enrollFromCloud});
}
