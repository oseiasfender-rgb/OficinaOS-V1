-- Private snapshots. No grants to anonymous callers; application writes only
-- through an authenticated compare-and-swap function. No automatic purging.
create table public.oficinaos_sync_heads (
  owner_id uuid not null references auth.users(id),
  namespace text not null check (namespace in ('homologacao','producao')),
  revision bigint not null check (revision > 0),
  payload jsonb not null,
  updated_at timestamptz not null default now(),
  primary key(owner_id,namespace)
);
create table public.oficinaos_sync_versions (
  owner_id uuid not null references auth.users(id),
  namespace text not null check (namespace in ('homologacao','producao')),
  revision bigint not null check (revision > 0),
  operation_id uuid not null,
  payload jsonb not null,
  created_at timestamptz not null default now(),
  primary key(owner_id,namespace,revision),
  unique(owner_id,namespace,operation_id)
);
alter table public.oficinaos_sync_heads enable row level security;
alter table public.oficinaos_sync_versions enable row level security;
revoke all on public.oficinaos_sync_heads, public.oficinaos_sync_versions from public, anon, authenticated;
grant select on public.oficinaos_sync_heads, public.oficinaos_sync_versions to authenticated;
create policy office_head_owner_read on public.oficinaos_sync_heads for select to authenticated using ((select auth.uid())=owner_id);
create policy office_version_owner_read on public.oficinaos_sync_versions for select to authenticated using ((select auth.uid())=owner_id);

create function public.oficinaos_sync_commit(p_namespace text,p_base_revision bigint,p_operation_id uuid,p_payload jsonb)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  caller uuid := auth.uid(); current_revision bigint := 0; previous public.oficinaos_sync_versions;
  bytes_used bigint; collection text; rows jsonb; required_collection text;
begin
  if caller is null then raise exception 'Authentication required' using errcode='42501'; end if;
  if p_namespace not in ('homologacao','producao') or p_namespace is null or p_base_revision is null or p_base_revision < 0 or p_operation_id is null then
    raise exception 'Invalid sync arguments' using errcode='22023';
  end if;
  perform pg_advisory_xact_lock(hashtextextended(caller::text||':'||p_namespace,0));
  select * into previous from public.oficinaos_sync_versions
    where owner_id=caller and namespace=p_namespace and operation_id=p_operation_id;
  if found then
    if previous.payload is distinct from p_payload or previous.revision <> p_base_revision+1 then
      raise exception 'Operation identity reused with different content' using errcode='22023';
    end if;
    return jsonb_build_object('revision',previous.revision);
  end if;
  if p_payload is null or p_payload->>'schema' is distinct from 'oficinaos-modular-v5'
     or jsonb_typeof(p_payload->'stores') is distinct from 'object' then
    raise exception 'Invalid snapshot schema' using errcode='22023';
  end if;
  foreach required_collection in array array['transactions','accounts','clients','jobs','workOrders','appointments','checklists','budgets','categories','goals','stock','operationalHistory','budgetHistory','archivedBudgets','trash','deletionBackups','deletionLog','recurringTemplates','settings','meta'] loop
    if jsonb_typeof(p_payload->'stores'->required_collection) is distinct from 'array' then
      raise exception 'Missing snapshot collection: %',required_collection using errcode='22023';
    end if;
  end loop;
  for collection, rows in select * from jsonb_each(p_payload->'stores') loop
    if jsonb_typeof(rows) is distinct from 'array' then raise exception 'Invalid collection' using errcode='22023'; end if;
    if exists(select 1 from jsonb_array_elements(rows) r where jsonb_typeof(r) is distinct from 'object' or coalesce(jsonb_typeof(r->'id'),'null') not in ('string','number') or btrim(r->>'id')='') then
      raise exception 'Invalid record identity' using errcode='22023';
    end if;
    if exists(select 1 from jsonb_array_elements(rows) r group by r->'id' having count(*)>1) then
      raise exception 'Duplicate record identity' using errcode='22023';
    end if;
  end loop;
  if octet_length(p_payload::text)>8388608 then raise exception 'Snapshot exceeds 8 MiB; no data changed' using errcode='54000'; end if;
  select revision into current_revision from public.oficinaos_sync_heads where owner_id=caller and namespace=p_namespace for update;
  current_revision:=coalesce(current_revision,0);
  if current_revision<>p_base_revision then raise exception 'Sync conflict: preserve both copies' using errcode='40001'; end if;
  select coalesce(sum(octet_length(payload::text)),0) into bytes_used from public.oficinaos_sync_versions where owner_id=caller;
  if bytes_used+octet_length(p_payload::text)>67108864 then raise exception 'Backup quota reached; export copies before maintenance' using errcode='54000'; end if;
  insert into public.oficinaos_sync_versions(owner_id,namespace,revision,operation_id,payload) values(caller,p_namespace,current_revision+1,p_operation_id,p_payload);
  insert into public.oficinaos_sync_heads(owner_id,namespace,revision,payload) values(caller,p_namespace,current_revision+1,p_payload)
    on conflict(owner_id,namespace) do update set revision=excluded.revision,payload=excluded.payload,updated_at=now();
  return jsonb_build_object('revision',current_revision+1);
end;
$$;
revoke all on function public.oficinaos_sync_commit(text,bigint,uuid,jsonb) from public,anon;
grant execute on function public.oficinaos_sync_commit(text,bigint,uuid,jsonb) to authenticated;
