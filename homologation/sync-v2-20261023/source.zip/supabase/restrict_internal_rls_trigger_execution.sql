-- Already applied remotely as restrict_internal_rls_trigger_execution.
revoke execute on function public.rls_auto_enable() from public, anon, authenticated;
