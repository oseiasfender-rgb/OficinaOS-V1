alter table public.oficinaos_sync_heads drop constraint oficinaos_sync_heads_namespace_check;
alter table public.oficinaos_sync_heads add constraint oficinaos_sync_heads_namespace_check check(namespace in ('homologacao','producao','homologacao_v2'));
alter table public.oficinaos_sync_versions drop constraint oficinaos_sync_versions_namespace_check;
alter table public.oficinaos_sync_versions add constraint oficinaos_sync_versions_namespace_check check(namespace in ('homologacao','producao','homologacao_v2'));
do $migration$
declare definition text;
begin
  definition := pg_get_functiondef('public.oficinaos_sync_commit(text,bigint,uuid,jsonb)'::regprocedure);
  if position('p_namespace not in (''homologacao'',''producao'')' in definition)=0 then
    raise exception 'Unexpected commit function: migration aborted';
  end if;
  execute replace(definition,'p_namespace not in (''homologacao'',''producao'')','p_namespace not in (''homologacao'',''producao'',''homologacao_v2'')');
end;
$migration$;
