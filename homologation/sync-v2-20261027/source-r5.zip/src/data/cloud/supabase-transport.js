import {SyncConflict} from './sync-engine.js';

export function createSupabaseTransport({url,publishableKey,getSession,fetchImpl=fetch}) {
  const parsed=new URL(url);
  if(parsed.protocol!=='https:' || !parsed.hostname.endsWith('.supabase.co') || parsed.username || parsed.password || parsed.pathname!=='/')throw Error('Informe a URL HTTPS do projeto Supabase.');
  if(!/^sb_publishable_[A-Za-z0-9_-]+$/.test(publishableKey))throw Error('Use somente a chave pública publishable do projeto.');
  async function request(path,body){
    const session=await getSession();
    if(!session?.access_token)throw Error('Entre na conta da oficina antes de sincronizar.');
    const response=await fetchImpl(new URL(path,parsed).href,{signal:AbortSignal.timeout(20000),method:body?'POST':'GET',headers:{apikey:publishableKey,Authorization:`Bearer ${session.access_token}`,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});
    if(!response.ok){
      const failure=await response.json().catch(()=>({}));
      if(failure.code==='40001')throw new SyncConflict();
      throw Error(response.status===401?'Sessão expirada. Entre novamente.':`Falha na nuvem (${response.status}). Nenhum dado local foi apagado.`);
    }
    return response.json();
  }
  return Object.freeze({
    read:async({namespace})=>{const rows=await request(`/rest/v1/oficinaos_sync_heads?namespace=eq.${encodeURIComponent(namespace)}&select=revision,payload`);if(!Array.isArray(rows)||rows.length>1)throw Error('Resposta da nuvem inválida.');return rows[0]??null;},
    commit:async({namespace,baseRevision,operationId,payload})=>request('/rest/v1/rpc/oficinaos_sync_commit',{p_namespace:namespace,p_base_revision:baseRevision,p_operation_id:operationId,p_payload:payload})
  });
}
