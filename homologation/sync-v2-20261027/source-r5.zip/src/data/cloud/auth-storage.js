import {transactionDone} from '../indexeddb.js';

// Authentication must not depend on the small localStorage quota shared with
// legacy applications on this origin. Never clear operational data to log in.
export async function createAuthStorage({indexedDBImpl=globalThis.indexedDB,legacyStorage=()=>globalThis.localStorage,namespace='homologacao'}={}){
  const prefix=`oficinaos-auth:${namespace}`;
  const allowed=key=>key===prefix||key.startsWith(`${prefix}-`);
  const db=await new Promise((resolve,reject)=>{
    const req=indexedDBImpl.open(`oficinaos_auth_${namespace}_v1`,1);
    req.onupgradeneeded=()=>req.result.createObjectStore('sessions');
    req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
  });
  async function setItem(key,value){
    if(!allowed(key))throw Error('Chave de sessão inválida.');
    const tx=db.transaction('sessions','readwrite');const done=transactionDone(tx);
    tx.objectStore('sessions').put(value,key);
    await done;
  }
  return {
    async getItem(key){
      if(!allowed(key))return null;
      const value=await new Promise((resolve,reject)=>{const r=db.transaction('sessions').objectStore('sessions').get(key);r.onsuccess=()=>resolve(r.result??null);r.onerror=()=>reject(r.error);});
      if(value!==null)return value;
      let old;try{old=legacyStorage()?.getItem(key);}catch{return null;}
      if(old==null)return null;
      await setItem(key,old);
      try{legacyStorage()?.removeItem(key);}catch{/* Retain persisted session. */}
      return old;
    },
    async setItem(key,value){await setItem(key,value);try{legacyStorage()?.removeItem(key);}catch{/* No dependency on legacy quota. */}},
    async removeItem(key){
      if(!allowed(key))throw Error('Chave de sessão inválida.');
      const tx=db.transaction('sessions','readwrite');const done=transactionDone(tx);tx.objectStore('sessions').delete(key);await done;
      try{legacyStorage()?.removeItem(key);}catch{/* Legacy storage may be unavailable. */}
    }
  };
}
