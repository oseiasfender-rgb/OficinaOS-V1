import {snapshotIdentity} from './sync-engine.js';
import {recordChanges,mergeRecords} from './record-merge.js';
const allowed=new Set(['clients','categories','goals','budgets']);
const key=(store,id)=>`${store}/${typeof id}:${id}`;
export function previewMissingRestore(current,historical){
  snapshotIdentity(current);snapshotIdentity(historical);
  const changes=recordChanges(current,historical);
  return {identity:snapshotIdentity(current),items:changes.filter(c=>c.operation!=='delete').map(c=>({
    key:key(c.collection,c.after.id),collection:c.collection,id:c.after.id,
    eligible:c.operation==='create'&&allowed.has(c.collection)&&!c.after.approval,
    reason:c.operation!=='create'?'Registro atual preservado; a restauração não o substitui':!allowed.has(c.collection)?'Financeiro, execução, configurações e históricos exigem recuperação própria':c.after.approval?'Orçamento aprovado exige revisão própria':'Registro ausente recuperável'
  }))};
}
export function applyMissingRestore(current,historical,selected,expectedIdentity){
  const plan=previewMissingRestore(current,historical);
  if(plan.identity!==expectedIdentity)throw Error('Dados mudaram. Refaça a prévia de restauração.');
  if(!Array.isArray(selected)||!selected.length||new Set(selected).size!==selected.length)throw Error('Selecione registros ausentes para recuperar.');
  const allowedKeys=new Set(plan.items.filter(x=>x.eligible).map(x=>x.key));
  if(selected.some(k=>!allowedKeys.has(k)))throw Error('Restauração bloqueada para registro existente, aprovado ou protegido.');
  const next=structuredClone(current);
  for(const [store,rows]of Object.entries(historical.stores))for(const row of rows)if(selected.includes(key(store,row.id)))next.stores[store].push(structuredClone(row));
  const integrity=mergeRecords(current,current,next);
  if(integrity.conflicts.length)throw Error('Recuperação cria conflito de numeração ou vínculo. Revise os registros.');
  return next;
}
