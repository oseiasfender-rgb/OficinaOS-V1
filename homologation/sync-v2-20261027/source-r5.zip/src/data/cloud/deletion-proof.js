// Permanent deletion is accepted only with its exact, unrecovered versioned
// backup and audit record. An absent row or a timestamp alone is not proof.
function stable(v){if(Array.isArray(v))return '['+v.map(stable).join(',')+']';if(v&&typeof v==='object')return '{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+stable(v[k])).join(',')+'}';return JSON.stringify(v);}
function version(row){const copy=structuredClone(row);if(['Arquivado','Na lixeira'].includes(copy.status))copy.status=copy.statusBeforeArchive||'Salvo';for(const key of ['bucket','entityType','deletedAt','deletedFrom','archivedAt','statusBeforeArchive'])delete copy[key];return copy;}
export function confirmedPermanentDeletion(snapshot,row){
 if(!row||row.approval)return false;
 const stores=snapshot.stores;
 if(['budgets','archivedBudgets','trash'].some(k=>(stores[k]??[]).some(r=>r.id===row.id)))return false;
 const logs=(stores.deletionLog??[]).filter(r=>r.entityType==='budget'&&r.entityId===String(row.id)&&r.reason==='exclusao-definitiva').sort((a,b)=>String(b.at).localeCompare(String(a.at)));
 const log=logs[0];if(!log||log.recoveredAt||!Number.isFinite(Date.parse(log.at)))return false;
 const backup=(stores.deletionBackups??[]).find(r=>r.id===log.backupId);
 if(!backup||backup.reason!=='exclusao-definitiva'||backup.recoveredAt||!Number.isFinite(Date.parse(backup.at))||Date.parse(backup.at)>Date.parse(log.at))return false;
 const item=backup.item??backup.payload;
 if(!item||item.id!==row.id||item.approval||stable(version(item))!==stable(version(row)))return false;
 if(backup.item&&backup.payload&&stable(version(backup.item))!==stable(version(backup.payload)))return false;
 const references=v=>v===row.id||(Array.isArray(v)?v.some(references):v&&typeof v==='object'?Object.values(v).some(references):false);
 for(const name of ['transactions','accounts','workOrders','appointments','checklists','jobs','budgetHistory'])if((stores[name]??[]).some(references))return false;
 return true;
}
