// Serializa as operações compostas na origem; evita gravações sobre snapshots concorrentes.
const queues=new WeakMap();
export function withWorkflowLock(repositories,operation){
 const run=()=>globalThis.navigator?.locks?.request?globalThis.navigator.locks.request('oficinaos-workflow-write',operation):operation();
 const previous=queues.get(repositories)||Promise.resolve();const next=previous.catch(()=>{}).then(run);queues.set(repositories,next);return next;
}
