// Presentation only: IDs, field names and persisted labels stay unchanged.
export const NAV_ICONS=Object.freeze({overview:'🔄',budget:'📋',finance:'💰',clients:'🤝',categories:'🏷️',stock:'📦',settings:'⚙️',agenda:'📅',workOrders:'🛠️',history:'🗂️',reports:'📈',consultant:'📖'});
export const PROCESS_ICONS=Object.freeze({desmontagem:'🔩',funilaria:'⚒️',solda:'⚡',preparacao:'🧽',pintura:'🎨',montagem:'✅',polimento:'✨'});
export const HEADING_ICONS=Object.freeze({'Orçamento':'📋','Financeiro':'💰','Contas':'🧾','Clientes':'🤝','Categorias':'🏷️','Estoque':'📦','Configurações':'⚙️','Agenda':'📅','Ordens de Serviço':'🛠️','Históricos':'🗂️','Relatórios':'📊','Metas':'🎯','Manual da oficina':'📖','Identificação da oficina':'🏢','Nova categoria':'🏷️','Categorias cadastradas':'🏷️','Pesquisar e filtrar':'🔎','Cadastrar material':'📦','Itens do estoque':'📦','OS cadastradas':'🛠️','DAS MEI':'🧾','Novo lançamento / edição':'💰','Transferência entre saldos':'🔄','Lançamentos':'📋','Metas por categoria':'🎯'});
const shapes={
 '🖨️':'<path d="M6 8V2h12v6M6 17H3V8h18v9h-3M6 14h12v8H6zM17 11h1"/>',
 '📋':'<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V2h6v2M9 10h6M9 14h6M9 18h4"/>',
 '💰':'<path d="M8 3h8l-2 4c8 7 9 14-2 14S2 14 10 7z"/><path d="M9 12h5a2 2 0 0 1 0 4h-4m2-6v8"/>',
 '🤝':'<path d="m2 9 5-5 5 2 5-2 5 5-4 4-6-5-5 5-5-4m5 4 6 6 5-6m-9 2 4 4m0-4 2 2"/>',
 '🏷️':'<path d="M3 3h8l10 10-8 8L3 11z"/><circle cx="7" cy="7" r="1"/>',
 '📦':'<path d="m3 7 9-4 9 4v11l-9 4-9-4zM3 7l9 4 9-4M12 11v11M7 5l9 4"/>',
 '⚙️':'<circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="2"/><path d="M12 2v4m0 12v4M2 12h4m12 0h4M5 5l3 3m8 8 3 3M5 19l3-3m8-8 3-3"/>',
 '📅':'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 2v6m10-6v6M3 11h18M7 15h3m4 0h3m-10 3h3"/>',
 '🛠️':'<path d="m4 3 6 6-2 3-6-6m6 6 10 10 3-3L11 9M17 2a5 5 0 0 0-5 6L3 17l4 4 9-9a5 5 0 0 0 6-5l-4 2-3-3z"/>',
 '🗂️':'<path d="M2 7h8l2 3h10l-3 11H3zM4 7V3h7l2 2h7v5"/>',
 '📈':'<path d="M3 3v18h18M6 15l5-5 4 3 6-8m-5 0h5v5"/>',
 '📊':'<path d="M3 3v18h19M7 17v-5m5 5V7m5 10V3"/>',
 '📖':'<path d="M12 5C8 2 4 2 2 3v17c3-1 7-1 10 2 3-3 7-3 10-2V3c-3-1-7-1-10 2v17"/>',
 '🔄':'<path d="M20 8a9 9 0 0 0-16-2L2 9m0-6v6h6m-4 7a9 9 0 0 0 16 2l2-3m0 6v-6h-6"/>',
 '💾':'<path d="M3 3h15l3 3v15H3zM7 3v6h10V3M7 21v-8h10v8"/>',
 '✅':'<rect x="3" y="3" width="18" height="18" rx="3"/><path d="m7 12 4 4 7-8"/>',
 '⚡':'<path d="m13 2-9 12h7l-1 8 10-13h-8z"/>',
 '🏁':'<path d="M4 22V3c6-5 10 5 16 0v12c-6 5-10-5-16 0m5-12v12m6-10v12M4 8c6-5 10 5 16 0"/>',
 '🚗':'<path d="m4 10 2-6h12l2 6M3 10h18v9H3zM5 19v3m14-3v3M6 14h2m8 0h2"/>',
 '🚚':'<path d="M2 5h12v13H2zM14 10h4l4 5v3h-8"/><circle cx="6" cy="19" r="2"/><circle cx="18" cy="19" r="2"/>',
 '🔧':'<path d="M20 3a6 6 0 0 0-8 7L3 19l3 3 9-9a6 6 0 0 0 7-8l-4 4-3-3z"/>',
 '🔩':'<path d="m7 2 5 3 5-3 5 8-5 3v7l-5 3-5-3v-7l-5-3zM7 13h10m-10 4h10"/>',
 '⚒️':'<path d="m3 4 6-2 6 6-3 3-3-3-6 3zM10 10l10 11 2-2-10-10"/>',
 '🧽':'<rect x="3" y="5" width="18" height="14" rx="4"/><path d="M6 9h2m3 0h2m3 0h2M8 14h2m4 0h2"/>',
 '🎨':'<path d="M12 2a10 10 0 1 0 0 20h2c3 0 3-4 0-5-2-1-1-3 1-3h3c6 0 4-12-6-12z"/><circle cx="7" cy="9" r="1"/><circle cx="11" cy="6" r="1"/><circle cx="16" cy="7" r="1"/>',
 '✨':'<path d="m12 3 3 6 6 3-6 3-3 6-3-6-6-3 6-3zM20 1v5m-2-3h5"/>',
 '🧾':'<path d="M5 2h14v20l-3-2-4 2-4-2-3 2zM8 7h8M8 11h8m-8 4h5"/>',
 '🎯':'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
 '🏢':'<path d="M4 22V2h16v20M2 22h20M8 6h2m4 0h2M8 10h2m4 0h2M8 14h2m4 0h2m-5 8v-4h2v4"/>',
 '🔎':'<circle cx="10" cy="10" r="7"/><path d="m15 15 7 7"/>'
};
export function markIcon(node,symbol){if(symbol){node.dataset.uiIcon=symbol;const shape=shapes[symbol]||shapes['📋'];const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#a25316" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${shape}</svg>`;node.style.setProperty('--ui-icon-image',`url("data:image/svg+xml,${encodeURIComponent(svg)}")`);}return node;}
