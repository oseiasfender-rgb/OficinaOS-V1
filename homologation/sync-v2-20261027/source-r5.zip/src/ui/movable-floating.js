export function makeFloatingMovable(button,host){
 let start=null,moved=false,suppressUntil=0,top=null;
 const place=y=>{top=Math.max(12,Math.min(innerHeight-button.offsetHeight-12,y));button.style.top=`${top}px`;button.style.bottom='auto';document.documentElement.style.setProperty('--pix-top',`${top}px`);const panelHeight=Math.min(560,innerHeight-24),below=innerHeight-top-68,panelTop=below>=Math.min(panelHeight,300)?top+64:Math.max(12,top-panelHeight-8);host.style.top=`${panelTop}px`;host.style.bottom='auto';host.style.maxHeight=`${Math.min(panelHeight,innerHeight-panelTop-12)}px`;};
 button.style.touchAction='none';button.title='PIX avulso — arraste para subir/descer; setas do teclado também movem';
 button.addEventListener('pointerdown',e=>{if(e.button!==0)return;start={y:e.clientY,top:button.getBoundingClientRect().top};moved=false;button.setPointerCapture(e.pointerId);});
 button.addEventListener('pointermove',e=>{if(!start)return;if(Math.abs(e.clientY-start.y)>6)moved=true;if(moved)place(start.top+e.clientY-start.y);});
 button.addEventListener('pointerup',()=>{if(moved)suppressUntil=performance.now()+300;start=null;});button.addEventListener('pointercancel',()=>{start=null;});
 button.addEventListener('click',e=>{if(performance.now()<suppressUntil){e.preventDefault();e.stopImmediatePropagation();}},true);
 button.addEventListener('keydown',e=>{if(!['ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();place(button.getBoundingClientRect().top+(e.key==='ArrowUp'?-24:24));});
 window.addEventListener('resize',()=>{if(top!=null)place(top);});
}
