export const STOCK_CATEGORIES=Object.freeze({funil:'Funilaria',solda:'Solda',prep:'Preparação',masc:'Mascaramento',pint:'Pintura',polit:'Polimento',limp:'Limpeza',outros:'Outros'});
export const UNITS=Object.freeze(['Un','Kg','L','Rolo','Caixa','Bobina']);
