import { withWorkflowLock } from '../../core/workflow-lock.js';
import { isPaid } from '../financeiro/financial-model.js';
import { safeText } from '../../core/validators.js';
import { findRecordById, validateWorkflowDates } from '../workflow.js';

function clone(v){return structuredClone(v);}
function num(v){const n=Number(v??0);return Number.isFinite(n)?n:0;}
function now(){return new Date().toISOString();}
function today(){return now().slice(0,10);}

export function createAgendaService({repositories,eventBus,store,workOrders,checklists}){
  const repo=repositories.appointments;
  const clientsRepo=repositories.clients;
  const budgetsRepo=repositories.budgets;
  const deletionBackupRepo=repositories.deletionBackups;

  async function syncStore(){store?.patch?.({appointments:await repo.list(),workOrders:await repositories.workOrders.list(),jobs:await repositories.jobs.list(),budgets:await budgetsRepo.list()});}
  async function changed(action,row){await syncStore();eventBus?.emit?.('agenda:changed',{action,id:row?.id});}
  async function getRequired(id){const row=await repo.get(id);if(!row)throw new Error('Agendamento não encontrado.');return row;}

  async function resolve(input={}){
    const budgetId=input.budgetId??input.orcamentoId??null;
    const budget=await findRecordById(budgetsRepo,budgetId);
    if(budgetId!=null && budgetId!=='' && !budget)throw new Error('Orçamento vinculado não encontrado.');
    const clientId=input.clientId??input.clienteId??budget?.clientId??budget?.clienteId??null;
    const budgetClientId=budget?.clientId??budget?.clienteId;
    if(budgetClientId!=null && clientId!=null && String(budgetClientId)!==String(clientId))throw new Error('O cliente selecionado não corresponde ao cliente do orçamento.');
    const client=await findRecordById(clientsRepo,clientId);
    if(clientId!=null && clientId!=='' && !client)throw new Error('Cliente vinculado não encontrado.');
    return {budget,client,clientId:client?.id??null,clientName:safeText(input.clientName??input.cliente??client?.name??client?.nome??budget?.cliente,120)};
  }

  async function transferBudgetPhotos(osId,budget){
    if(!budget?.stagePhotos?.length)return;
    const current=await repositories.workOrders.get(osId),photos=clone(current.stagePhotos||[]);
    for(const photo of budget.stagePhotos)if(!photos.some(p=>p.id===photo.id))photos.push({...clone(photo),originBudgetId:budget.id});
    if(photos.length>30)throw new Error('As fotos excedem o limite da OS.');
    if(photos.length!==(current.stagePhotos||[]).length)await repositories.workOrders.put({...current,stagePhotos:photos});
  }
  async function create(input={}){
    const resolved=await resolve(input);
    if(!resolved.clientName)throw new Error('Cliente é obrigatório.');
    const date=safeText(input.date??input.data??input.entrada??today(),10);
    const dueDate=safeText(input.dueDate??input.entrega??input.dataEntrega,10);
    if(!date&&!dueDate)throw new Error('Informe ao menos uma data para a Agenda.');
    validateWorkflowDates(date,dueDate);
    let workOrderId=input.workOrderId??input.osId??null;
    let os=workOrderId?await workOrders.get(workOrderId):null;
    if(workOrderId!=null && !os)throw new Error('OS vinculada não encontrada.');
    if(!os){
      const existing=resolved.budget ? (await workOrders.list()).find(row=>String(row.budgetId)===String(resolved.budget.id)) : null;
      os=existing??await workOrders.create({
        budgetId:resolved.budget?.id??input.budgetId??input.orcamentoId??null,
        clientId:resolved.clientId,clientName:resolved.clientName,
        vehicle:input.vehicle??input.veiculo??resolved.budget?.veiculo,
        service:input.service??input.servico??input.tipo??resolved.budget?.servico,
        entryDate:date,dueDate:dueDate||date,value:num(input.value??input.valor??input.val??resolved.budget?.total),
        notes:input.notes??input.obs,priority:input.priority??input.prioridade
      });
      workOrderId=os.id;
      if(!existing && resolved.budget?.id!=null && checklists) await checklists.copyBudgetToWorkOrder(resolved.budget.id, os.id);
    }
    const duplicate=(await repo.list()).find(row=>String(row.workOrderId)===String(workOrderId)&&String(row.date)===String(date)&&row.status!=='Cancelado');
    if(duplicate){await transferBudgetPhotos(os.id,resolved.budget);await changed('photos-sync',duplicate);return duplicate;}
    const id=input.id??`ag_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,7)}`;
    const row={
      ...clone(input),id,workOrderId,clientId:os.clientId??resolved.clientId,budgetId:os.budgetId??resolved.budget?.id??null,
      date:date||os.entryDate||today(),dueDate:dueDate||os.dueDate||'',time:safeText(input.time??input.hora??'08:00',5),
      type:safeText(input.type??input.tipo??'Entrada',80),status:os.status==='Entregue'?'Concluído':safeText(input.status??'Agendado',40),
      clientName:os.clientName??resolved.clientName,vehicle:safeText(input.vehicle??input.veiculo??os.vehicle,160),
      service:safeText(input.service??input.servico??input.tipoServico??os.service,240),value:num(input.value??input.valor??input.val??os.value),
      notes:safeText(input.notes??input.obs??os.notes,1500),createdAt:input.createdAt??now(),updatedAt:now()
    };
    if(resolved.budget?.stagePhotos?.length){const current=await repositories.workOrders.get(os.id);const ids=new Set((current.stagePhotos||[]).map(p=>p.id));if((current.stagePhotos||[]).length+resolved.budget.stagePhotos.filter(p=>!ids.has(p.id)).length>30)throw new Error('As fotos excedem o limite da OS.');}
    await repo.put(row);
    await workOrders.update(os.id,{entryDate:row.date,dueDate:row.dueDate||os.dueDate,clientName:row.clientName,vehicle:row.vehicle,service:row.service,value:row.value,notes:row.notes});
    await transferBudgetPhotos(os.id,resolved.budget);
    await changed('create',row);return row;
  }

  async function updateImpact(id,changes={}){
    const current=await getRequired(id),merged={...current,...clone(changes)};
    const resolved=await resolve({...merged,clientName:undefined});
    const next={...merged,clientId:resolved.clientId,budgetId:resolved.budget?.id??null,clientName:resolved.clientName||merged.clientName,id:current.id,updatedAt:now()};
    if(!next.clientName)throw new Error('Cliente é obrigatório.');
    validateWorkflowDates(next.date,next.dueDate);if(!Number.isFinite(Number(next.value))||Number(next.value)<0)throw new Error('Valor inválido.');next.value=Number(next.value);
    const financialChange=['clientId','budgetId','clientName','vehicle','service','value'].some(k=>String(next[k]??'')!==String(current[k]??''));
    const affected=financialChange?(await repositories.transactions.list()).filter(t=>t.type==='rec'&&((current.workOrderId!=null&&[t.workOrderId,t.osId].some(v=>v!=null&&String(v)===String(current.workOrderId)))||(current.budgetId!=null&&String(t.budgetId??t.orcId??'')===String(current.budgetId)))):[];
    const receipts=(await repositories.settings.get('fp_receipt_snapshots'))?.value||[];if(affected.some(t=>receipts.some(r=>String(r.transactionId)===String(t.id)&&!r.canceledAt)))throw new Error('Cancele os recibos preparados antes de alterar a Agenda.');
    if(affected.some(t=>isPaid(t.paid)))throw new Error('Há receita paga vinculada. Corrija explicitamente o recebimento e os recibos no Financeiro antes de alterar os dados comerciais.');
    if(next.budgetId!=null&&(await repositories.workOrders.list()).some(os=>String(os.id)!==String(current.workOrderId)&&String(os.budgetId??'')===String(next.budgetId)))throw new Error('Orçamento já vinculado a outra OS.');
    return {current,next,affected};
  }

  return Object.freeze({
    previewUpdate:async(id,changes)=>{const x=await updateImpact(id,changes);return {affectedTransactions:x.affected.map(t=>({id:t.id,value:t.val,description:t.desc})),requiresConfirmation:x.affected.length>0};},
    async list({year,month,status='',query=''}={}){
      const q=safeText(query,120).toLocaleLowerCase('pt-BR');
      return (await repo.list()).filter(row=>{
        if(status&&row.status!==status)return false;
        const d=new Date(`${row.date||row.dueDate||'1970-01-01'}T00:00:00`);
        if(Number.isInteger(year)&&d.getFullYear()!==year)return false;
        if(Number.isInteger(month)&&d.getMonth()!==month)return false;
        if(q&&![row.clientName,row.vehicle,row.service].some(v=>safeText(v).toLocaleLowerCase('pt-BR').includes(q)))return false;
        return true;
      }).sort((a,b)=>String(a.date??'').localeCompare(String(b.date??''))||String(a.time??'').localeCompare(String(b.time??'')));
    },
    get:id=>repo.get(id),
    async clients(){return clientsRepo.list();},
    async budgets(){return budgetsRepo.list();},
    async budgetContext(id){const budget=await findRecordById(budgetsRepo,id);if(!budget)return null;const client=await findRecordById(clientsRepo,budget.clientId??budget.clienteId);return {budget,client};},
    create,
    async createFromBudget(budgetId,input={}){return create({...input,budgetId});},
    async update(id,changes={},options={}){return withWorkflowLock(repositories,async()=>{
      const {current,next,affected}=await updateImpact(id,changes);
      if(affected.length&&!options.confirmFinancial)throw new Error('Confirme os lançamentos pendentes afetados antes de salvar.');
      const stores=['appointments','workOrders','jobs','budgets','transactions','operationalHistory'];
      const snapshots=await Promise.all(stores.map(k=>repositories[k].list()));
      await deletionBackupRepo.put({id:`agenda_update_${id}_${Date.now()}`,at:now(),entityType:'workflowUpdate',reason:'agenda-update',payload:{appointment:current,transactions:affected}});
      try{
        if(next.workOrderId)await workOrders.update(next.workOrderId,{entryDate:next.date,dueDate:next.dueDate,clientId:next.clientId,budgetId:next.budgetId,clientName:next.clientName,vehicle:next.vehicle,service:next.service,value:next.value,notes:next.notes});
        if(current.budgetId!=null&&String(current.budgetId)!==String(next.budgetId)){const old=await budgetsRepo.get(current.budgetId);if(old&&String(old.osId)===String(current.workOrderId))await budgetsRepo.put({...old,osId:null});}
        await repo.put(next);
        for(const t of affected)await repositories.transactions.put({...t,budgetId:next.budgetId,clientId:next.clientId,clientName:next.clientName,vehicle:next.vehicle,val:next.value,desc:`Serviço — ${next.clientName} — ${next.service}`});
      }catch(error){try{for(let i=0;i<stores.length;i++)await repositories[stores[i]].replaceAll(snapshots[i]);await syncStore();}catch(rollback){throw new Error(`Falha ao salvar e recuperar Agenda: ${error.message}; ${rollback.message}`);}throw error;}
      await changed('update',next);return next;});
    },
    async markDone(id){const row=await getRequired(id);const next={...row,status:'Concluído',updatedAt:now()};await repo.put(next);if(next.workOrderId)await workOrders.markDelivered(next.workOrderId);await changed('complete',next);return next;},
    async reopen(id){const row=await getRequired(id);const next={...row,status:'Agendado',updatedAt:now()};await repo.put(next);if(next.workOrderId)await workOrders.reopen(next.workOrderId);await changed('reopen',next);return next;},
    async remove(id){const row=await getRequired(id);await deletionBackupRepo?.put({id:`appointment_${id}_${Date.now()}`,at:now(),entityType:'appointment',reason:'appointment-delete',payload:clone(row)});await repo.delete(id);await changed('delete',row);return row;}
  });
}
