import {formatBRL} from '../../core/money.js';
// Presentation only: known subtotals stay visible, without declaring an incomplete quote final.
export function buildBudgetSummary(draft,c){
 const missing=c.missing||[],sale=draft.pricingVersion===2,pack=draft.pricingMode==='package';
 const group=(value,present,pattern)=>{
  if(!sale)return formatBRL(value);
  if(pack)return 'Coberto no pacote';
  if(!present)return 'Não adicionado';
  const pending=missing.some(m=>pattern.test(m));
  return pending?(value===0?'Não informado':`${formatBRL(value)} · parcial`):formatBRL(value);
 };
 const laborPending=missing.some(m=>/^(Horas |Horas previstas|Preço de venda da hora|Justificativa da complexidade|Dificuldade já)/.test(m));
 const incomplete=sale&&!c.complete;
 return {
  labor:pack?'Coberta no pacote':sale&&laborPending?(c.labor===0?'Não informado':`${formatBRL(c.labor)} · parcial`):formatBRL(c.labor),
  materials:group(c.materials,!!draft.materials?.length,/^(Quantidade material |Custo material |Acréscimo de (?:materials|materiais))/),
  parts:group(c.serviceItemsNet+c.recoveredParts,!!(draft.parts?.length||draft.serviceItems?.length),/^(Quantidade peça |Custo peça |Acréscimo de (?:parts|peças)|Quantidade serviço |Preço serviço |Desconto fixo)/),
  extras:group(c.extras,!!(draft.thirdParties?.length||Object.values(draft.freight||{}).some(v=>v!=null&&v!=='')),/^(Custo terceiro |Acréscimo de (?:thirdParties|terceiros)|Frete )/),
  base:c.base==null?'Não informado':formatBRL(c.base),
  baseLabel:(pack?'Preço do pacote':sale?'Composição de venda':'Base × complexidade')+(incomplete?' — parcial':''),
  discount:c.discountAmount==null?'Não informado':`− ${formatBRL(c.discountAmount)}${sale&&missing.some(m=>/^Desconto global/.test(m))?' · parcial':''}`,
  total:c.final==null?'Pendente de revisão':formatBRL(c.final),
  pending:incomplete?'Orçamento incompleto. Valores parciais; não são preço final. Pendências: '+missing.map(m=>m.replace('Acréscimo de materials','Acréscimo de materiais').replace('Acréscimo de parts','Acréscimo de peças').replace('Acréscimo de thirdParties','Acréscimo de terceiros')).join('; '):''
 };
}
