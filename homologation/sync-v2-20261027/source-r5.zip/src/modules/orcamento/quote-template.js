import { formatBRL } from '../../core/money.js';
const WIDTH=794, HEIGHT=1123, M=24, W=WIDTH-M*2, INK='#321b10', ACCENT='#a65b18', LIGHT='#f4e7d8';
const value=v=>String(v??'').trim();
let measuringContext;
export function measureDocumentText(text,size=11,bold=false){
 if(typeof document!=='undefined'){
  measuringContext ||= document.createElement('canvas').getContext('2d');
  if(measuringContext){measuringContext.font=`${bold?'bold ':''}${size}px Arial`;return measuringContext.measureText(String(text)).width;}
 }
 // Conservative fallback for non-browser callers; exports use the actual Arial metrics.
 return String(text).length*size*.8;
}
export function quotePages(model,measure=measureDocumentText){
 const receipt=model.documentKind==='receipt';const pages=[];let commands=[],y=0;
 const rect=(x,y,w,h,fill='#fff',stroke='#b8a08e')=>commands.push({kind:'rect',x,y,w,h,fill,stroke});
 const txt=(text,x,y,size=11,bold=false,color=INK)=>commands.push({kind:'text',text:value(text),x,y,size,bold,color});
 function wrap(text,width,size,bold=false){const lines=[];for(const paragraph of value(text).split(/\n/)){let line='';for(const word of paragraph.split(/\s+/)){if(measure(word,size,bold)>width){if(line){lines.push(line);line='';}let piece='';for(const ch of word){if(measure(piece+ch,size,bold)>width){lines.push(piece);piece='';}piece+=ch;}line=piece;continue;}if(line&&measure(line+' '+word,size,bold)>width){lines.push(line);line=word;}else line+=(line?' ':'')+word;}lines.push(line);}return lines.length?lines:[''];}
 function lines(text,x,top,width,size=11,bold=false){const ls=wrap(text,width,size,bold);ls.forEach((t,i)=>txt(t,x,top+i*(size+5),size,bold));return ls.length*(size+5);}
 function footer(){txt(model.footerText||`${model.companyOwner?model.companyOwner+' - ':''}${model.companyName}`,M,HEIGHT-38,10);}
 function start(){commands=[];const x=model.companyLogo?112:M;if(model.companyLogo)commands.push({kind:'image',src:model.companyLogo,x:M,y:26,w:72,h:72});if(model.companyName!=='OficinaOS')txt('OficinaOS',x,18,11,true,ACCENT);const nh=lines(model.companyName||'OficinaOS',x,39,500-x,22,true);const ch=lines([model.companyPhone,model.companyAddress,model.companyCity].filter(Boolean).join(' | '),x,44+nh,500-x,10);rect(530,22,240,7,ACCENT,ACCENT);txt(model.documentTitle||(receipt?'RECIBO':'ORÇAMENTO'),530,46,14,true);const qh=lines(model.quoteNumber||'RASCUNHO',530,67,240,13,true);txt(model.issueDate,530,72+qh,11);const bottom=Math.max(125,49+nh+ch,100+qh);rect(M,bottom,W,1,INK,INK);y=bottom+20;}

 function finish(){footer();pages.push({width:WIDTH,height:HEIGHT,commands});}
 function space(h){if(y+h>HEIGHT-75){finish();start();}}
 function block(title,text,x=M,width=W){const ls=wrap(text,width-24,11),h=28+ls.length*16+14;space(h);rect(x,y,width,h);rect(x,y,width,24,ACCENT,ACCENT);txt(title,x+12,y+7,11,true,'#fff');ls.forEach((s,i)=>txt(s,x+12,y+35+i*16));return h;}
 start();
 const metaAll=[['Responsável',model.companyOwner],['CNPJ / CPF',model.companyDocument],['Validade',model.validityDays?`${model.validityDays} dias`: 'Não informada'],['Pagamento',model.payment],['Prioridade',({normal:'Normal',urgente:'Urgente',programado:'Programado'})[model.priority]||model.priority],['Garantia',String(model.warrantyDays)==='0'?'Sem garantia':model.warrantyDays?`${model.warrantyDays} dias no serviço`:'Não informada']];
 const meta=receipt?metaAll.filter(([label])=>!['Validade','Garantia','Prioridade'].includes(label)):metaAll;let metaY=y;for(const [label,v]of meta){txt(label+':',M,metaY,11,true);metaY+=lines(v||'Não informado',M+100,metaY,model.photo&&model.photoPosition==='header'?205:W-110)+12;}
 const headerPhotoHeight=({small:150,medium:210,large:280})[model.photoSize]||210;if(model.photo&&model.photoPosition==='header'){if(receipt)txt('ANTES',350,y,11,true);commands.push({kind:'image',src:model.photo,x:350,y:y+(receipt?18:0),w:420,h:headerPhotoHeight});}y=Math.max(metaY,y+(model.photo&&model.photoPosition==='header'?headerPhotoHeight+(receipt?33:15):0))+10;
 if(!receipt)photoSection();
 const clientText=[model.clientName,model.clientPhone?`Telefone: ${model.clientPhone}`:''].filter(Boolean).join('\n');const dateText=receipt?model.issueDate:model.deadlineText||model.dueDate||'A combinar';space(42+Math.max(wrap(clientText,356,11).length,wrap(dateText,330,11).length)*16);
 let h=block('CLIENTE',[model.clientName,model.clientPhone?`Telefone: ${model.clientPhone}`:''].filter(Boolean).join('\n'),M,380);let h2=block(receipt?'RECEBIMENTO':'PRAZO',receipt?model.issueDate:model.deadlineText||model.dueDate||'A combinar',416,354);y+=Math.max(h,h2)+10;
 h=block('VEÍCULO',[model.vehicle,model.vehicleYear?`Ano ${model.vehicleYear}`:'',model.vehiclePlate?`Placa ${model.vehiclePlate}`:'',model.vehicleColor].filter(Boolean).join('\n'),M,receipt?W:380);h2=receipt?0:block('COMPLEXIDADE',model.commercialComplexity||'Não informada',416,354);y+=Math.max(h,h2)+10;
 // Escopo e notas extensos são divididos em blocos para evitar corte de conteúdo.
 function longBlock(title,text){const ls=wrap(text,W-24,11);while(ls.length){const capacity=Math.max(1,Math.floor((HEIGHT-75-y-44)/16));if(capacity<2){finish();start();continue;}const chunk=ls.splice(0,capacity);const bh=block(title,chunk.join('\n'));y+=bh+12;title+=' (continuação)';}}
 longBlock(receipt?'SERVIÇO REALIZADO':'SERVIÇO AVALIADO',(receipt?model.service:model.serviceName||model.service)||'Serviço conforme avaliação técnica.');if(!receipt){const damage=model.problemDescription||'',process=model.technicalProcess||'';const leftHeight=42+wrap(damage,356,11).length*16,rightHeight=42+wrap(process,330,11).length*16;if(damage&&process&&Math.max(leftHeight,rightHeight)<330){space(Math.max(leftHeight,rightHeight)+12);const dh=block('DANO AVALIADO',damage,M,380),ph=block('PROCESSO TÉCNICO',process,416,354);y+=Math.max(dh,ph)+12;}else{if(damage)longBlock('DANO AVALIADO',damage);if(process)longBlock('PROCESSO TÉCNICO',process);}if(model.includedServices)longBlock('SERVIÇOS INCLUÍDOS',model.includedServices);}
 function photoSection(){const photos=[...(model.photo&&model.photoPosition!=='header'?[{src:model.photo,label:receipt?'Antes':'Sinistro'}]:[]),...(model.documentPhotos||[])];const sizes={small:150,medium:230,large:340},height=sizes[model.photoSize]||230;for(const photo of photos){space(height+55);rect(M,y,W,24,ACCENT,ACCENT);txt('FOTO - '+photo.label,M+12,y+7,11,true,'#fff');y+=30;commands.push({kind:'image',src:photo.src,x:M,y,w:W,h:height});y+=height+15;}}

 function tableHead(){space(60);rect(M,y,W,24,ACCENT,ACCENT);txt(receipt?'SERVIÇOS E VALORES RECEBIDOS':'COMPOSIÇÃO DO ORÇAMENTO',M+12,y+7,11,true,'#fff');y+=24;rect(M,y,W,26,LIGHT,LIGHT);txt('Item',M+12,y+8,11,true);txt('Descrição',220,y+8,11,true);txt('Valor',680,y+8,11,true);y+=26;}
 tableHead();
 const groups=model.groups||[{rows:[...model.items,...model.parts.map(p=>({...p,description:p.condition}))]}];
 for(const group of groups){
  function groupHead(continued=false){if(!group.label)return;space(72);rect(M,y,W,26,LIGHT,LIGHT);txt(group.label+(continued?' (continuação)':''),M+12,y+8,11,true);if(!continued&&group.rows.length>1){txt(formatBRL(group.total),WIDTH-M-12,y+8,11,true);commands.at(-1).align='right';}y+=26;}
  groupHead();
  for(const item of group.rows){
   const valueWidth=Math.max(98,measure(formatBRL(item.value),11)+18);const label=wrap(item.label,172,11,true),desc=wrap(item.description||'',WIDTH-M-12-valueWidth-220,11),rh=Math.max(44,Math.max(label.length,desc.length)*16+18);
   if(y+rh>HEIGHT-125){finish();start();tableHead();groupHead(true);}
   rect(M,y,W,rh);label.forEach((t,i)=>txt(t,M+12,y+14+i*16,11,true));desc.forEach((t,i)=>txt(t,220,y+14+i*16,11));txt(formatBRL(item.value),WIDTH-M-12,y+14,11);commands.at(-1).align='right';y+=rh;
  }
 }
 space(60);rect(M,y,W,42,LIGHT);txt(model.totalLabel||'TOTAL DO INVESTIMENTO',M+12,y+14,12,true);txt(formatBRL(model.total),WIDTH-M-12,y+13,16,true,ACCENT);commands.at(-1).align='right';y+=58;
 const approval='Nome: ________________________\nAssinatura: _____________________\nData: ____/____/________';
 const noteLines=wrap(model.notes||'Condições conforme avaliação e pagamento informado.',450-24,11);
 if(noteLines.length<=5){const bottomHeight=Math.max(90,42+noteLines.length*16);space(bottomHeight);const nh=block(receipt?'DECLARAÇÃO DE RECEBIMENTO':'CONDIÇÕES E OBSERVAÇÕES',noteLines.join('\n'),M,450);const ah=block(model.signatureTitle||'APROVAÇÃO DO CLIENTE',approval,486,284);y+=Math.max(nh,ah);}
 else{longBlock(receipt?'DECLARAÇÃO DE RECEBIMENTO':'CONDIÇÕES E OBSERVAÇÕES',model.notes);space(90);y+=block(model.signatureTitle||'APROVAÇÃO DO CLIENTE',approval);}
 if(receipt)photoSection();
 finish();
 pages.forEach((p,i)=>p.commands.push({kind:'text',text:`${i+1}/${pages.length}`,x:735,y:HEIGHT-38,size:10,color:INK}));return pages;
}
export function renderQuotePage(page){
 const sheet=document.createElement('article');sheet.className='commercial-print-sheet';sheet.style.cssText=`position:relative;width:${page.width}px;height:${page.height}px;background:white;color:${INK};padding:0;font-family:Arial,sans-serif;box-sizing:border-box;overflow:hidden`;
 for(const c of page.commands){const e=document.createElement(c.kind==='image'?'img':'div');e.style.position='absolute';e.style.left=c.x+'px';e.style.top=c.y+'px';if(c.kind==='text'){e.textContent=c.text;e.style.cssText+=`;font-size:${c.size}px;font-weight:${c.bold?700:400};color:${c.color};white-space:pre;line-height:1.2`;if(c.align==='right')e.style.transform='translateX(-100%)';}else{e.style.width=c.w+'px';e.style.height=c.h+'px';if(c.kind==='image'){e.src=c.src;e.style.objectFit='contain';}else e.style.cssText+=`;background:${c.fill};border:1px solid ${c.stroke};box-sizing:border-box`;}sheet.append(e);}return sheet;
}
export async function quotePngBlobs(pages){
 const blobs=[];for(const page of pages){const canvas=document.createElement('canvas');canvas.width=page.width*2;canvas.height=page.height*2;const ctx=canvas.getContext('2d');ctx.scale(2,2);ctx.fillStyle='#fff';ctx.fillRect(0,0,page.width,page.height);
 for(const c of page.commands){if(c.kind==='text'){ctx.font=`${c.bold?'bold ':''}${c.size}px Arial`;ctx.fillStyle=c.color;ctx.textBaseline='top';ctx.textAlign=c.align==='right'?'right':'left';ctx.fillText(c.text,c.x,c.y);}else if(c.kind==='rect'){ctx.fillStyle=c.fill;ctx.fillRect(c.x,c.y,c.w,c.h);ctx.strokeStyle=c.stroke;ctx.strokeRect(c.x+.5,c.y+.5,c.w-1,c.h-1);}else{const img=new Image();img.src=c.src;await img.decode();const scale=Math.min(c.w/img.width,c.h/img.height);ctx.drawImage(img,c.x+(c.w-img.width*scale)/2,c.y+(c.h-img.height*scale)/2,img.width*scale,img.height*scale);}}
 blobs.push(await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('Não foi possível gerar a imagem.')),'image/png')));}return blobs;
}
