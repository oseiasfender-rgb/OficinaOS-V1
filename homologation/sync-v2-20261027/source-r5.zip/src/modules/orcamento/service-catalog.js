import {withWorkflowLock} from '../../core/workflow-lock.js';
import {optionalNumber} from './sale-pricing.js';
const KEY='workshop_service_catalog_v1';
const clone=v=>structuredClone(v),text=v=>String(v??'').trim().slice(0,4000),id=p=>`${p}_${globalThis.crypto.randomUUID()}`;
export const CATEGORY_MODELS=['Diagnóstico e serviços preliminares','Funilaria e chaparia','Recuperação de plásticos e fibras','Preparação de superfície','Pintura automotiva','Acabamento e entrega'];
export function createServiceCatalog(repositories){
 const repo=repositories.settings;
 async function read(){return clone((await repo.get(KEY))?.value??{schemaVersion:1,categories:[],services:[]});}
 async function write(fn){return withWorkflowLock(repositories,async()=>{const state=await read(),result=await fn(state);await repo.put({id:KEY,value:state,updatedAt:new Date().toISOString()});return clone(result);});}
 const latest=r=>({...clone(r.versions.at(-1)),id:r.id});
 return {
  state:read,
  list:async()=>{const s=await read();return s.services.map(latest);},
  async saveCategory(input){return write(s=>{const name=text(input.name);if(!name)throw Error('Informe o nome da categoria.');if(s.categories.some(c=>c.id!==input.id&&c.name.toLocaleLowerCase('pt-BR')===name.toLocaleLowerCase('pt-BR')))throw Error('Já existe uma categoria com esse nome.');let r=s.categories.find(r=>r.id===input.id);if(input.id&&!r)throw Error('Categoria não encontrada.');if(!r){r={id:id('cat'),name,active:true,order:s.categories.length};s.categories.push(r);}Object.assign(r,{name,active:input.active!==false});return r;});},
  async loadCategoryModels(){return write(s=>{let added=0;for(const name of CATEGORY_MODELS)if(!s.categories.some(c=>c.name.toLocaleLowerCase('pt-BR')===name.toLocaleLowerCase('pt-BR'))){s.categories.push({id:id('cat'),name,active:true,order:s.categories.length});added++;}return {added};});},
  async save(input,{responsible,reason,expectedVersionId}={}){return write(s=>{
   const name=text(input.name),category=s.categories.find(c=>c.id===input.categoryId),unit=text(input.unit);if(!name||!category||!['serviço','peça','hora','ponto'].includes(unit))throw Error('Informe nome, categoria e unidade.');if(!text(responsible)||!text(reason))throw Error('Informe responsável e motivo da versão.');
   let row=s.services.find(r=>r.id===input.id);if(input.id&&!row)throw Error('Serviço não encontrado.');if(row&&row.versions.at(-1).versionId!==expectedVersionId)throw Error('Serviço alterado em outra operação. Reabra a edição.');
   const price=optionalNumber(input.price),hours=optionalNumber(input.hours,true),status=['rascunho','ativo','inativo'].includes(input.status)?input.status:'rascunho',pricingKind=input.pricingKind==='labor'?'labor':'package';
   if(status==='ativo'&&(price==null||!text(input.inclusions)||!text(input.exclusions)))throw Error('Para ativar, informe preço, inclusões e exclusões (use “Nenhuma” quando aplicável).');
   const version={versionId:id('srvv'),at:new Date().toISOString(),responsible:text(responsible),reason:text(reason),name,categoryId:category.id,categoryName:category.name,unit,detail:text(input.detail),price,hours,inclusions:text(input.inclusions),exclusions:text(input.exclusions),status,pricingKind,priceMeaning:'finalSuggested'};
   if(!row){row={id:id('srv'),versions:[]};s.services.push(row);}row.versions.push(version);return latest(row);
  });},
  async versions(serviceId){const s=await read();return clone(s.services.find(r=>r.id===serviceId)?.versions??[]);}
 };
}
