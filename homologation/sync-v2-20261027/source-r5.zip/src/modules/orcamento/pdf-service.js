import {commercialSignature} from './commercial-signature.js';
import { documentFiles } from '../documentos/document-files.js';
import { formatBRL } from '../../core/money.js';
import { calculateBudget, partAmount, complexityFrom } from './orcamento-calculator.js';
import { quotePages, renderQuotePage, quotePngBlobs } from './quote-template.js';
import { draftFromBudget } from './orcamento-model.js';

function arr(v){return Array.isArray(v)?v:[];}
function text(v){return String(v??'').trim();}

export function buildCommercialQuoteModel(record, settings = {}, options={}){
  const liveStagePhotos=record.stagePhotos||[];
  if(record.approval?.snapshot){if(commercialSignature(record)!==commercialSignature(record.approval.snapshot))throw new Error('Orçamento aprovado: crie uma revisão antes de alterar o documento comercial.');settings=record.approval.documentSettings??settings;record={...record.approval.snapshot,id:record.id};}
  const draft=draftFromBudget(record); const calc=calculateBudget(draft);
  if(calc.complete===false)throw new Error('Orçamento incompleto: '+calc.missing.join('; '));
  const commercialFactor=calc.manualBase>0?calc.final/calc.manualBase:0;
  const parts=[],extras=[],combined={label:'Mão de obra e materiais',description:'Serviço e insumos incluídos',value:0};
  let packageRow=null,hasCombined=false;
  if(calc.usesLegacyTotalFallback)packageRow={label:'Serviço contratado',description:'Serviços e materiais inclusos conforme avaliação',value:calc.final};
  else if(draft.pricingVersion===2){
    for(const row of calc.commercialLines){const item={label:row.label,description:row.description||'',value:row.value*(1-calc.discountRate)};
      if(row.kind==='package')packageRow=item;
      else if(['labor','materials'].includes(row.kind)){combined.value+=item.value;hasCombined=true;}
      else if(row.kind==='parts')parts.push({...item,condition:row.condition||'',description:row.condition||'Peça / componente'});
      else extras.push({...item,description:row.description||'Serviço complementar'});
    }
  }else{
    combined.value=(calc.labor+calc.materials)*commercialFactor;hasCombined=combined.value>0;
    for(const row of arr(draft.parts).filter(p=>text(p.name)||Number(p.value)>0))parts.push({label:text(row.name)||'Peça / componente',condition:text(row.condition),description:text(row.condition),value:partAmount(row)*commercialFactor});
    const itemFactor=calc.serviceItems>0?calc.serviceItemsNet/calc.serviceItems:0;
    for(const row of draft.serviceItems){const v=Number(row.qty)*Number(row.value)*itemFactor*commercialFactor;if(v>0)extras.push({label:row.stage||'Serviço',description:row.desc,value:v});}
    if(calc.thirdParties>0)extras.push({label:'Serviços de terceiros',description:'Serviços complementares',value:calc.thirdParties*commercialFactor});
    if(calc.freight>0)extras.push({label:'Frete / deslocamento',description:'Transporte',value:calc.freight*commercialFactor});
  }
  const groups=packageRow?[{label:'Serviço contratado em pacote',rows:[packageRow]}]:[
    {label:'Mão de obra e materiais',rows:hasCombined?[combined]:[]},
    {label:'Peças',rows:parts},
    {label:'Serviços e extras',rows:extras}
  ].filter(g=>g.rows.length);
  // Distribui os centavos nos preços comerciais, sem expor margem, desconto ou custos separados.
  const all=groups.flatMap(g=>g.rows);let allocated=0,cumulative=0;
  all.forEach((item,index)=>{cumulative+=item.value;const target=index===all.length-1?Math.round(calc.final*100):Math.round(cumulative*100);item.value=(target-allocated)/100;allocated=target;});
  for(const group of groups)group.total=group.rows.reduce((s,r)=>s+Math.round(r.value*100),0)/100;
  const items=groups.filter(g=>g.label!=='Peças').flatMap(g=>g.rows);
  return Object.freeze({
    documentTitle:'ORÇAMENTO',companyLogo:/^data:image\/(?:jpeg|png);base64,[A-Za-z0-9+/=]+$/.test(settings.logo||'')?settings.logo:'',documentPhotos:options.stagePhotoIds?liveStagePhotos.filter(p=>options.stagePhotoIds.includes(p.id)).map((p,i)=>({src:p.dataUrl,label:`Sinistro ${i+1}`})):[],photoSize:['small','medium','large'].includes(options.photoSize)?options.photoSize:'medium',photoPosition:options.photoPosition==='header'?'header':'start',quoteNumber:text(record.numero ?? record.number ?? record.id), companyName:text(settings.nome ?? settings.companyName ?? 'OficinaOS'), companyOwner:text(settings.dono ?? settings.owner), companyPhone:text(settings.fone ?? settings.phone), companyDocument:text(settings.cnpj ?? settings.document), companyCity:text(settings.cidade ?? settings.city), companyAddress:text(settings.endereco ?? settings.address),companySubtitle:text(settings.subtitulo ?? settings.subtitle),
    clientName:draft.clientName, clientPhone:draft.clientPhone, vehicle:draft.vehicle, vehiclePlate:draft.vehiclePlate, vehicleYear:draft.vehicleYear, vehicleColor:draft.vehicleColor,
    technicalProcess:draft.technicalProcess||'',includedServices:draft.includedServices||'',serviceName:draft.service,problemDescription:draft.problemDescription,priority:draft.priority,service:[draft.service,draft.problemDescription].filter(Boolean).join('\n'), entryDate:draft.entryDate, dueDate:draft.dueDate, notes:draft.notes, payment:draft.payment, warrantyDays:draft.warrantyDays,
    validityDays:draft.validityDays,deadlineText:draft.deadlineText,commercialComplexity:draft.commercialComplexity||complexityFrom(draft.complexity).label,photo:options.includeVehiclePhoto===true?draft.quotePhoto:'',issueDate:(draft.entryDate||new Date().toISOString().slice(0,10)).split('-').reverse().join('/'),
    groups:Object.freeze(groups),items:Object.freeze(items), parts:Object.freeze(parts), total:Math.round(calc.final*100)/100,
    generatedAt:new Date().toISOString()
  });
}

function pagesFor(model){const ctx=document.createElement('canvas').getContext('2d');return quotePages(model,(t,size)=>{ctx.font=`${size}px Arial`;return ctx.measureText(String(t)).width;});}
export function printCommercialQuote(record,settings={},options={}){
  const model=buildCommercialQuoteModel(record,settings,options),overlay=document.createElement('div');overlay.className='commercial-print-overlay';
  for(const page of pagesFor(model))overlay.append(renderQuotePage(page));document.body.append(overlay);
  const cleanup=()=>overlay.remove();window.addEventListener('afterprint',cleanup,{once:true});window.print();setTimeout(cleanup,60000);return model;
}
export async function downloadCommercialQuotePng(record,settings={},options={}){
  const model=buildCommercialQuoteModel(record,settings,options),blobs=await quotePngBlobs(pagesFor(model));
  const base=`Orcamento_${model.quoteNumber||'rascunho'}`.replace(/[^a-zA-Z0-9_-]/g,'_');
  for(const [i,blob]of blobs.entries()){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`${base}_${i+1}.png`;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);}return {pages:blobs.length};
}

export async function commercialQuoteFiles(record,settings={},format='pdf',options={}){const model=buildCommercialQuoteModel(record,settings,options);return documentFiles(pagesFor(model),`Orcamento_${model.quoteNumber||'rascunho'}`,format);}

export function renderCommercialQuotePreview(host,record,settings={},options={}){
 const model=buildCommercialQuoteModel(record,settings,options),sheets=[];host.replaceChildren();
 for(const page of pagesFor(model)){const wrap=document.createElement('div'),sheet=renderQuotePage(page);wrap.style.cssText='position:relative;overflow:hidden;margin:12px auto;background:white;';sheet.style.transformOrigin='top left';wrap.append(sheet);host.append(wrap);sheets.push({wrap,sheet,page});}
 const resize=()=>{const width=Math.max(1,host.clientWidth);for(const {wrap,sheet,page}of sheets){const scale=Math.min(1,width/page.width);wrap.style.width=page.width*scale+'px';wrap.style.height=page.height*scale+'px';sheet.style.transform=`scale(${scale})`;}};const observer=new ResizeObserver(resize);observer.observe(host);resize();return()=>observer.disconnect();
}
