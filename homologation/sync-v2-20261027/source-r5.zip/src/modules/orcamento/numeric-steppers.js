import {el,button} from '../../ui/dom.js';
import {optionalNumber} from './sale-pricing.js';
const observers=new WeakMap();
export function numericSpec(label){
 if(/%/.test(label))return {kind:'percent',step:1,max:/^Margem %$/.test(label)?99.99:/^Desconto %$/.test(label)?100:Infinity};
 if(/^(?:Qtd\.?|Quantidade.*|Mínimo|Horas.*)$/.test(label))return {kind:'quantity',step:/^Horas/.test(label)?.5:1,max:Infinity};
 if(/(?:R\$|Custo|Valor|Preço|Frete de|Deslocamento|Reboque)/i.test(label))return {kind:'money',step:1,max:Infinity};
 return null;
}
export function stepNumericValue(raw,spec,direction){const value=optionalNumber(raw,spec.kind==='quantity')??0;const next=Math.max(spec.min??0,Math.min(spec.max,Math.round((value+direction*spec.step)*1e6)/1e6));return next.toLocaleString('pt-BR',{useGrouping:false,minimumFractionDigits:spec.kind==='money'?2:0,maximumFractionDigits:spec.kind==='money'?2:6});}
export function installBudgetNumericSteppers(root){
 observers.get(root)?.disconnect();
 function scan(){for(const ctl of root.querySelectorAll('input')){
  if(!['text','number'].includes(ctl.type)||ctl.closest('.budget-hour-stepper,.budget-numeric-stepper')||ctl.readOnly)continue;
  const label=ctl.getAttribute('aria-label')||'',spec=numericSpec(label);if(!spec)continue;
  const wrap=el('div','budget-numeric-stepper'),actions=el('div','budget-numeric-buttons');ctl.before(wrap);wrap.append(ctl);ctl.inputMode='decimal';
  const step=direction=>{if(ctl.disabled||ctl.readOnly)return;try{const bounds={...spec,min:ctl.min!==''?Number(ctl.min):0,max:Math.min(spec.max,ctl.max!==''?Number(ctl.max):Infinity)};const next=stepNumericValue(ctl.value,bounds,direction);ctl.setCustomValidity('');ctl.value=ctl.type==='number'?next.replace(',','.'):next;ctl.dispatchEvent(new Event('input',{bubbles:true}));ctl.dispatchEvent(new Event('change',{bubbles:true}));}catch{ctl.setCustomValidity('Informe um número válido e não negativo.');ctl.reportValidity();}};
  for(const [symbol,dir,verb]of [['▲',1,'Aumentar'],['▼',-1,'Diminuir']]){const b=button(symbol,'btn budget-numeric-step');b.setAttribute('aria-label',`${verb} ${label}`);b.title=`${verb} ${spec.step.toLocaleString('pt-BR')}${spec.kind==='money'?' real':spec.kind==='percent'?' ponto percentual':''}`;b.addEventListener('click',()=>step(dir));actions.append(b);}wrap.append(actions);
  ctl.addEventListener('keydown',e=>{if(e.key==='ArrowUp'||e.key==='ArrowDown'){e.preventDefault();step(e.key==='ArrowUp'?1:-1);}});ctl.addEventListener('input',()=>ctl.setCustomValidity(''));
 }}
 const observer=new MutationObserver(scan);observer.observe(root,{childList:true,subtree:true});observers.set(root,observer);scan();return ()=>observer.disconnect();
}
