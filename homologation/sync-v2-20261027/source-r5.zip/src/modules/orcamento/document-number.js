// Caller holds the workflow lock. Display numbers never replace entity IDs.
export async function nextBudgetNumber(repositories){
 const key='budget_document_sequence',saved=Number((await repositories.settings.get(key))?.value)||0;
 const rows=await repositories.budgets.list();const maximum=rows.reduce((n,r)=>Math.max(n,Number(/^orc_(\d+)$/.exec(String(r.numero||r.number||''))?.[1])||0),saved);const next=maximum+1;
 await repositories.settings.put({id:key,value:next,updatedAt:new Date().toISOString()});return `orc_${String(next).padStart(3,'0')}`;
}
