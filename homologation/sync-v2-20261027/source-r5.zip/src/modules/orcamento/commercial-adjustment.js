// Acréscimo sobre preço de venda e meta de resultado são decisões distintas.
export function applyCommercialAdjustment(calc,input){
 if(!['target','markup','sale-margin'].includes(input.marginMode))return calc; // histórico anterior preservado
 const raw=input.marginPercent,percent=Number(String(raw??0).replace(',','.'));
 const invalid=raw==null||String(raw).trim()===''||!Number.isFinite(percent)||percent<0||percent>100||(input.marginMode==='sale-margin'&&percent>=100);
 const missing=[...calc.missing,...(invalid?[input.marginMode==='sale-margin'?'Informe margem de precificação de 0% até menos de 100%':'Informe ajuste/meta entre 0 e 100%']:[])];
 const round=v=>Math.round((v+Number.EPSILON)*100)/100;
 const factor=!invalid?(input.marginMode==='sale-margin'?1/(1-percent/100):input.marginMode==='markup'?1+percent/100:1):1;
 const gross=calc.base==null?null:round(calc.base*factor),discountAmount=gross==null?null:round(gross*calc.discountRate),final=missing.length||gross==null?null:round(gross-discountAmount);
 const scenario=p=>calc.base==null||calc.missing.length?null:round(round(calc.base*(input.marginMode==='sale-margin'?1/(1-p/100):1+p/100))-round(round(calc.base*(input.marginMode==='sale-margin'?1/(1-p/100):1+p/100))*calc.discountRate));
 return {...calc,complete:!missing.length,missing,withMargin:gross,discountAmount,final,adjustmentMode:input.marginMode,adjustmentPercent:invalid?null:percent,targetPercent:input.marginMode==='target'?percent:null,netProfit:null,breakEven:null,scenarios:input.marginMode!=='target'?{margin20:scenario(20),margin30:scenario(30),margin50:scenario(50)}:{margin20:null,margin30:null,margin50:null},commercialLines:calc.commercialLines.map(r=>({...r,value:r.value==null?null:r.value*factor}))};
}
