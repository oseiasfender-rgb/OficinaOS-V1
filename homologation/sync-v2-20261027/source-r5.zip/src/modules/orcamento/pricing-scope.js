import {optionalNumber} from './sale-pricing.js';
export const OPERATION_STAGES=['desmontagem','funilaria','solda','preparacao','pintura','montagem','polimento'];
export function scopeProblems(input){
 const problems=[],seen=new Map();
 for(const [i,op] of (input.operations||[]).entries()){
  if(!String(op.part||'').trim()||!String(op.damage||'').trim()||!String(op.operation||'').trim())problems.push(`Operação ${i+1}: informe peça, dano e operação`);
  if(!OPERATION_STAGES.includes(op.stage))problems.push(`Operação ${i+1}: etapa inválida`);
  if(op.inclusion==='unknown'||!op.inclusion)problems.push(`Operação ${i+1}: inclusão não definida`);
  const norm=v=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLocaleLowerCase('pt-BR');
  const key=op.sharedId?`shared:${norm(op.sharedId)}`:[norm(op.part),norm(op.damage),norm(op.operation)].join('|');
  if(seen.has(key))problems.push(`Operações ${seen.get(key)+1} e ${i+1}: escopo repetido`);seen.set(key,i);
 }
 if(input.pricingMode==='package'){
  if(input.package?.priceBasis==='final-v1'&&!String(input.package?.name||'').trim())problems.push('Pacote: informe o nome do serviço');
  if(input.package?.priceBasis!=='final-v1'&&!(input.operations||[]).length)problems.push('Pacote: descreva as operações cobertas');
  if(!input.package?.coverageConfirmed)problems.push('Pacote: confirme inclusões e exclusões');
  if(!String(input.package?.inclusions||'').trim()||!String(input.package?.exclusions||'').trim())problems.push('Pacote: informe inclusões e exclusões, inclusive quando não houver');
  if((input.operations||[]).some(op=>op.inclusion!=='covered'))problems.push('Pacote: todas as operações devem estar cobertas; serviço adicional exige revisão do escopo');
 }
 return problems;
}
export function calculatePackage(input,complexity){
 const missing=scopeProblems(input),closed=input.package?.priceBasis==='final-v1';let price=null,discount=closed?0:null;
 try{price=optionalNumber(input.package?.price);if(!closed)discount=optionalNumber(input.discountPercent);}catch(e){missing.push(e.message);}
 if(price==null)missing.push('Preço comercial do pacote');if(discount==null)missing.push('Desconto global');if(discount>100)missing.push('Desconto acima de 100%');
 const final=missing.length?null:Math.round((price*(1-discount/100)+Number.EPSILON)*100)/100;
 const internalMissing=[];for(const [i,p] of (input.laborProcesses||[]).entries())if(p.hours==null||p.hours==='')internalMissing.push(`Horas internas ${i+1}`);
 return {pricingVersion:2,pricingMode:'package',complete:!missing.length,missing,internalMissing,hours:(input.laborProcesses||[]).reduce((s,r)=>s+(Number(String(r.hours??0).replace(',','.'))||0),0),rate:input.hourRate,labor:0,materials:0,recoveredParts:0,thirdParties:0,serviceItems:0,serviceItemsNet:0,serviceItemsDiscount:0,freight:0,extras:0,base:price,manualBase:price,withMargin:price,discountAmount:price==null||discount==null?null:price*discount/100,discountRate:discount/100,final,complexity,marginRate:0,effectiveMarginPercent:null,usesLegacyTotalFallback:false,scenarios:{margin20:null,margin30:null,margin50:null},commercialLines:[{kind:'package',label:input.package?.name||'Pacote de serviço',description:`Inclui: ${input.package?.inclusions||''}\nExclui: ${input.package?.exclusions||''}`,value:price}]};
}
