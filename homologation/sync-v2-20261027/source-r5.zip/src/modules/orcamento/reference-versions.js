import { withWorkflowLock } from '../../core/workflow-lock.js';
import {parseBRL} from '../../core/money.js';
const KEY='budget_reference_versions_v1',OLD='budget_price_reference_sudeste';
export function optionalMoney(value){if(value==null||String(value).trim()==='')return null;const raw=String(value).trim().replace(/R\$/gi,'').replace(/\s/g,'');if(!/^-?(?:\d+(?:[.,]\d+)?|\d{1,3}(?:\.\d{3})+(?:,\d+)?|\d{1,3}(?:,\d{3})+(?:\.\d+)?)$/.test(raw))throw new Error('Valor monetário inválido.');const n=parseBRL(value);if(n<0)throw new Error('Valor não pode ser negativo.');return n;}
export function documentReference(row){return {...structuredClone(row),kind:'documentary',region:'Sudeste',city:null,state:null,baseYear:2025,source:'Tabela de Preços Funilaria 2025 — Escola Do Autonomo',verification:'Pesquisa não verificada independentemente',includedOperations:null,excludedOperations:null,includedMaterials:null,applicableQuantity:null};}
export function createReferenceVersions(repositories,defaults){
 const repo=repositories.settings;
 async function state(){const saved=await repo.get(KEY);if(saved?.value)return structuredClone(saved.value);const prior=await repo.get(OLD);return {schemaVersion:1,versions:[],legacyEdits:Array.isArray(prior?.value)?structuredClone(prior.value):[]};}
 return {
  async documents(){return defaults.map(documentReference);},
  async history(){return state();},
  async current(){const s=await state();const latest=s.versions.at(-1);return latest?structuredClone(latest.rows):s.legacyEdits.length?defaults.map(d=>{const r=s.legacyEdits.find(r=>r.id===d.id);return r?{...documentReference(d),...r,kind:'workshop-legacy',verification:'Edição legada; responsável e motivo não informados'}:documentReference(d);}):defaults.map(documentReference);},
  async save(rows,{responsible,reason}={}){if(!String(responsible??'').trim()||!String(reason??'').trim())throw new Error('Informe responsável e motivo da versão própria.');return withWorkflowLock(repositories,async()=>{const s=await state();const ids=new Set();const normalized=rows.map(r=>{const source=defaults.find(d=>d.id===r.id);if(!source||ids.has(r.id))throw new Error('Referência inválida ou duplicada.');ids.add(r.id);return {...documentReference(source),mean:optionalMoney(r.mean),kind:'workshop',verification:'Valor próprio da oficina; não é média regional comprovada',originalMean:source.mean};});if(ids.size!==defaults.length)throw new Error('A versão deve preservar todas as referências.');const previous=s.versions.at(-1);const version={id:`refv_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,at:new Date().toISOString(),responsible:String(responsible).trim().slice(0,120),reason:String(reason).trim().slice(0,1000),previousVersionId:previous?.id??null,rows:normalized};s.versions.push(version);await repo.put({id:KEY,value:s,updatedAt:version.at});return structuredClone(version);});}
 };
}
