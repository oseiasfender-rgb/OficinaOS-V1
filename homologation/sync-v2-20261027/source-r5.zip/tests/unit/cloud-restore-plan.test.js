import test from 'node:test';
import assert from 'node:assert/strict';
import {previewMissingRestore,applyMissingRestore} from '../../src/data/cloud/restore-plan.js';
const s=(budgets=[],transactions=[])=>({schema:'oficinaos-modular-v5',stores:{budgets,transactions}});
test('Recuperação seletiva adiciona ausente e preserva trabalho atual',()=>{
 const current=s([{id:'new',total:20}]),old=s([{id:'old',total:10}]);const plan=previewMissingRestore(current,old);const restored=applyMissingRestore(current,old,['budgets/string:old'],plan.identity);assert.equal(restored.stores.budgets.length,2);assert.deepEqual(current.stores.budgets,[{id:'new',total:20}]);
});
test('Recuperação nunca reverte orçamento existente ou pagamento',()=>{
 const current=s([{id:'x',total:200}],[{id:'pay',paid:true}]),old=s([{id:'x',total:100}],[{id:'pay',paid:false},{id:'lost',paid:true}]);const plan=previewMissingRestore(current,old);assert.equal(plan.items.filter(x=>x.eligible).length,0);assert.throws(()=>applyMissingRestore(current,old,['transactions/string:lost'],plan.identity),/bloqueada/);
});
test('Restauração de aprovado e prévia vencida são bloqueadas',()=>{
 const current=s(),old=s([{id:'x',approval:{snapshot:{total:100}}}]);const plan=previewMissingRestore(current,old);assert.equal(plan.items[0].eligible,false);assert.throws(()=>applyMissingRestore(s([{id:'new'}]),old,['budgets/string:x'],plan.identity),/mudaram/);
});
