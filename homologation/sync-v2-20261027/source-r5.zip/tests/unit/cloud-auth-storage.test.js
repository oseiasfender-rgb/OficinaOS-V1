import test from 'node:test';
import assert from 'node:assert/strict';
import {IDBFactory} from 'fake-indexeddb';
import {createAuthStorage} from '../../src/data/cloud/auth-storage.js';
const key='oficinaos-auth:homologacao';
test('Sessão persiste e recarrega com localStorage cheio, sem apagar dados legados',async()=>{
  const factory=new IDBFactory(),legacy=new Map([['backup-oficina','preservar']]);
  const storage={getItem:k=>legacy.get(k)??null,setItem:()=>{throw new DOMException('Quota','QuotaExceededError');},removeItem:k=>legacy.delete(k)};
  const first=await createAuthStorage({indexedDBImpl:factory,legacyStorage:()=>storage});
  await first.setItem(key,'test-session');
  const second=await createAuthStorage({indexedDBImpl:factory,legacyStorage:()=>storage});
  assert.equal(await second.getItem(key),'test-session');assert.equal(legacy.get('backup-oficina'),'preservar');
  await second.removeItem(key);assert.equal(await first.getItem(key),null);assert.equal(legacy.get('backup-oficina'),'preservar');
});
test('Migra somente a sessão antiga, após persistência confirmada',async()=>{
  const values=new Map([[key,'old-session'],['office','preserved']]);
  const storage=await createAuthStorage({indexedDBImpl:new IDBFactory(),legacyStorage:()=>({getItem:k=>values.get(k)??null,removeItem:k=>values.delete(k)})});
  assert.equal(await storage.getItem(key),'old-session');assert.equal(values.has(key),false);assert.equal(values.get('office'),'preserved');assert.equal(await storage.getItem(key),'old-session');
});
test('Sessão funciona sem permissão para localStorage e ambientes ficam separados',async()=>{
  const factory=new IDBFactory(),legacyStorage=()=>{throw new Error('Denied');};
  const a=await createAuthStorage({indexedDBImpl:factory,legacyStorage});
  const b=await createAuthStorage({indexedDBImpl:factory,legacyStorage,namespace:'producao'});
  await a.setItem(key,'session');assert.equal(await b.getItem(key),null);await assert.rejects(a.setItem('office','bad'),/inválida/);assert.equal(await a.getItem(key),'session');
});
