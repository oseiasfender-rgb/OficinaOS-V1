import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateBudget } from '../../src/modules/orcamento/orcamento-calculator.js';
import { recordFromDraft, draftFromBudget } from '../../src/modules/orcamento/orcamento-model.js';

test('Cenários incluem desconto e coincidem com total ao aplicar a margem',()=>{
 const draft={hourRate:100,laborProcesses:[{hours:10}],materials:[{qty:2,unit:50}],complexity:'medio',discountPercent:10};
 for(const [margin,key] of [[20,'margin20'],[30,'margin30'],[50,'margin50']]){
  const calc=calculateBudget({...draft,marginPercent:margin});
  assert.ok(Math.abs(calc.final-calc.scenarios[key])<1e-9);
  const restored=draftFromBudget(recordFromDraft({...draft,marginPercent:margin}));
  assert.equal(restored.discountPercent,10);assert.equal(restored.marginPercent,margin);
  assert.equal(recordFromDraft(restored).total,Math.round(calc.final*100)/100);
 }
});
test('Cenários não recalculam total legado sem composição',()=>{
 const calc=calculateBudget({legacyTotal:150,discountPercent:10,marginPercent:30});
 assert.equal(calc.final,150);assert.deepEqual(Object.values(calc.scenarios),[150,150,150]);
});
test('Foto e aplicação da peça sobrevivem salvar, duplicar e JSON',()=>{
 const photo='data:image/jpeg;base64,AAAA';
 const record=recordFromDraft({clientName:'Teste',parts:[{catalogId:'p1',name:'Peça',foto:photo,application:'Veículo',value:50}]});
 const restored=draftFromBudget(JSON.parse(JSON.stringify(record)));
 assert.equal(restored.parts[0].foto,photo);assert.equal(restored.parts[0].application,'Veículo');
 const copy=recordFromDraft({...restored,id:'copy'});
 assert.equal(copy.parts[0].foto,photo);assert.equal(record.parts[0].foto,photo);
 assert.equal(draftFromBudget({parts:[{name:'Peça',foto:'https://example.org/photo.jpg'}]}).parts[0].foto,'');
});
