import test from 'node:test';
import assert from 'node:assert/strict';
import {calculateBudget} from '../../src/modules/orcamento/orcamento-calculator.js';
import {recordFromDraft,draftFromBudget} from '../../src/modules/orcamento/orcamento-model.js';
import {buildCommercialQuoteModel} from '../../src/modules/orcamento/pdf-service.js';
test('Peça unitária usa quantidade no resumo, no registro reaberto e no documento',()=>{
 const draft={clientName:'Teste isolado',parts:[{name:'Peça',qty:3,value:125.5,priceBasis:'unit'}],marginPercent:20,discountPercent:10};
 const record=recordFromDraft(draft);assert.equal(calculateBudget(draft).recoveredParts,376.5);assert.equal(calculateBudget(draftFromBudget(record)).recoveredParts,376.5);
 const model=buildCommercialQuoteModel(record);assert.equal(model.total,423.56);assert.equal(model.parts[0].value,423.56);
});
test('Peça antiga sem base unitária conserva o valor total mesmo com quantidade maior',()=>{
 const old={cliente:'Legado',parts:[{name:'Peça antiga',qty:3,value:125.5}],total:125.5};
 const draft=draftFromBudget(old);assert.equal(draft.parts[0].priceBasis,'total');assert.equal(calculateBudget(draft).recoveredParts,125.5);assert.equal(buildCommercialQuoteModel(recordFromDraft(draft,old)).total,125.5);
});
test('Horas e quantidades conservam três casas decimais com ponto ou vírgula',()=>{
 for(const v of ['2.125','2,125',2.125]){const c=calculateBudget({laborProcesses:[{hours:v}],hourRate:55,materials:[{qty:v,unit:10}]});assert.equal(c.hours,2.125);assert.equal(c.labor,116.875);assert.equal(c.materials,21.25);}
});
