import test from 'node:test';
import assert from 'node:assert/strict';
import {IDBFactory} from 'fake-indexeddb';
import {STORE_DEFINITIONS,DATA_SCHEMA} from '../../src/data/schema.js';
import {createLocalSyncAdapter,createDeviceMetadata,SYNC_STORES} from '../../src/data/cloud/local-adapter.js';
import {snapshotIdentity,SyncConflict} from '../../src/data/cloud/sync-engine.js';
import {transactionDone} from '../../src/data/indexeddb.js';

async function database(){
  const factory=new IDBFactory();
  const db=await new Promise((resolve,reject)=>{const req=factory.open('isolated-test',1);req.onupgradeneeded=()=>{for(const [name,def]of Object.entries(STORE_DEFINITIONS))req.result.createObjectStore(name,{keyPath:def.keyPath});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});
  const adapter=createLocalSyncAdapter({db,locks:{request:(_name,fn)=>fn()},canApply:()=>true});return {db,adapter,factory};
}
function full(value=0){return {schema:DATA_SCHEMA,stores:Object.fromEntries(SYNC_STORES.map(name=>[name,name==='budgets'?[{id:'q1',total:value}]:[]]))};}
test('Snapshot completo é aplicado em transação e pode ser lido sem perda de campos',async()=>{
  const {db,adapter}=await database();const before=await adapter.read();const incoming=full(125.75);incoming.stores.stock=[{id:1,qty:1.5}];incoming.stores.settings=[{id:'office',value:{name:'Teste'}}];await adapter.apply(incoming,snapshotIdentity(before));assert.deepEqual(await adapter.read(),incoming);db.close();
});
test('Concorrência detectada dentro da transação preserva os dados locais',async()=>{
  const {db,adapter}=await database();const before=await adapter.read();const tx=db.transaction('budgets','readwrite');tx.objectStore('budgets').put({id:'local',total:30});await transactionDone(tx);
  await assert.rejects(adapter.apply(full(500),snapshotIdentity(before)),SyncConflict);assert.deepEqual((await adapter.read()).stores.budgets,[{id:'local',total:30}]);db.close();
});
test('Cópia parcial, schema incompatível ou registros duplicados nunca limpam o banco',async()=>{
  const {db,adapter}=await database();const before=await adapter.read(),identity=snapshotIdentity(before);
  const bad=full(100);delete bad.stores.accounts;await assert.rejects(adapter.apply(bad,identity),/incompatível/);
  await assert.rejects(adapter.apply({...full(100),schema:'other'},identity),/incompatível/);
  const dup=full(100);dup.stores.budgets.push({id:'q1'});await assert.rejects(adapter.apply(dup,identity),/duplicada/);assert.deepEqual(await adapter.read(),before);db.close();
});
test('Cópia preventiva não integra a próxima sincronização e guarda o conteúdo original',async()=>{
  const {db,adapter}=await database();const before=await adapter.read();await adapter.backup(before,{reason:'test'});assert.deepEqual(await adapter.read(),before);
  const copy=await new Promise(resolve=>{const req=db.transaction('backups').objectStore('backups').getAll();req.onsuccess=()=>resolve(req.result);});assert.equal(copy.length,1);assert.deepEqual(copy[0].payload,before);db.close();
});
test('Metadados de aparelho persistem sem ir para o banco operacional',async()=>{
  const factory=new IDBFactory();const first=await createDeviceMetadata(factory);await first.set('a:homologacao',{revision:4});const second=await createDeviceMetadata(factory);assert.deepEqual(await second.get('a:homologacao'),{revision:4});assert.equal(await second.get('b:homologacao'),null);
});
