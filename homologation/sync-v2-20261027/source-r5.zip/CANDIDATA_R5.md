# Candidata Sync V2 r5 — 27/10/2026

Correção complementar: exclusão definitiva documentada.

A r4 bloqueava indevidamente uma remoção quando o orçamento já havia saído da Lixeira, mesmo existindo log e cópia preventiva da exclusão definitiva.
A r5 aceita a ausência somente quando há log de exclusão definitiva sem recuperação posterior, backup correspondente e a mesma versão completa do registro, sem aprovação ou vínculos de execução/financeiros. O backup permanece íntegro.
A comparação não ignora alterações comerciais ou fotos: uma versão diferente exige revisão.

Validação: 313 testes PASS, build PASS, escolhas de interface em Chromium desktop/celular PASS.
O backup exportado do G75 às 22h03 BRT de 27/10 confirma 7 ativos, 0 arquivados, 0 lixeira e os logs/cópias das exclusões de Abimaer e Rodrigo PC às 21h57. O orçamento de Rodrigo G75 R$757,14 está preservado.
A prova de exclusão desse backup foi comparada com a versão exata de Abimaer da revisão 39: PASS.
Não foi feita mutação direta na nuvem. Ainda depende de envio e conferência nos aparelhos físicos.

A aplicação inicia pausada e usa o banco de homologação existente. Feche r2/r4 antes de usar r5.
Não restaure novamente orçamentos para contornar o bloqueio.
