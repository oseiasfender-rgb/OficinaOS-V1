import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createSyncEngine,snapshotIdentity,SyncConflict} from '../src/data/cloud/sync-engine.js';
const [pcPath,g75Path]=process.argv.slice(2);
const pc=JSON.parse(fs.readFileSync(pcPath)).modular,g75=JSON.parse(fs.readFileSync(g75Path)).modular;
const normalize=s=>({schema:s.schema,stores:structuredClone(s.stores)});
// Simulated common base: exports do not contain device sync metadata.
const base=normalize(pc);const shared=new Set(g75.stores.budgets.map(r=>r.id));base.stores.budgets=base.stores.budgets.filter(r=>shared.has(r.id));
let local=normalize(g75),head={revision:1,payload:normalize(pc)};const backups=[];
const state=new Map([['tester:homologacao_v2',{revision:0,identity:snapshotIdentity(base)}]]);
const engine=createSyncEngine({userId:'tester',namespace:'homologacao_v2',metadata:{get:async k=>state.get(k),set:async(k,v)=>state.set(k,v)},local:{read:async()=>structuredClone(local),withLock:fn=>fn(),canApply:async()=>true,backup:async s=>backups.push(structuredClone(s)),apply:async(s,identity)=>{assert.equal(snapshotIdentity(local),identity);local=structuredClone(s);}},remote:{read:async()=>structuredClone(head),commit:async x=>{if(x.baseRevision!==head.revision)throw new SyncConflict();head={revision:head.revision+1,payload:structuredClone(x.payload)};return{revision:head.revision};}}});
const review=await engine.inspectConflicts();const choices={};
for(const c of review.conflicts){if(c.reason==='duplicate-document-number')choices[`budgets/${c.key}`]=c.key==='orc_007'?'retain:orc_mvpvb3zd_tvvyp':'keep-all';else choices[`${c.collection}/${c.key}`]='local';}
await engine.resolveConflicts(review,choices);
assert.equal(local.stores.budgets.length,8);assert.equal(new Set(local.stores.budgets.map(r=>r.numero)).size,8);
assert.equal(local.stores.budgets.find(r=>r.id==='orc_mvpvb3zd_tvvyp').total,757.14);
assert.equal(local.stores.archivedBudgets.find(r=>r.id==='orc_mvpvdhnh_svi1i').total,1060);
for(const r of g75.stores.budgets){const after=local.stores.budgets.find(x=>x.id===r.id);assert.ok(after);assert.equal(after.quotePhoto,r.quotePhoto);assert.deepEqual(after.stagePhotos,r.stagePhotos);}
await engine.tick();assert.equal(snapshotIdentity(head.payload),snapshotIdentity(local));
console.log(JSON.stringify({status:'PASS',scope:'Backups reais, base comum reconstruida, servidor simulado; nao comprova metadados dos aparelhos nem nuvem real',active:local.stores.budgets.length,archived:local.stores.archivedBudgets.length,backups:backups.length,rodrigo:757.14,numbers:local.stores.budgets.map(r=>({id:r.id,number:r.numero}))},null,2));
