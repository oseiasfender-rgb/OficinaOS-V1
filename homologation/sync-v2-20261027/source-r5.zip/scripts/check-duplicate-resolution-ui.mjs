import {spawn} from 'node:child_process';
import {chromium} from 'playwright';
import assert from 'node:assert/strict';
const server=spawn(process.execPath,['node_modules/vite/bin/vite.js','--host','127.0.0.1','--port','5197'],{stdio:'ignore'});
for(let n=0;n<100;n++){try{if((await fetch('http://127.0.0.1:5197')).ok)break;}catch{}await new Promise(r=>setTimeout(r,100));}
const browser=await chromium.launch({headless:true,executablePath:process.env.OFICINAOS_CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-gpu','--disable-dev-shm-usage']});
try{
 for(const viewport of [{width:1366,height:768},{width:412,height:915}]){
  const page=await browser.newPage({viewport});await page.goto('http://127.0.0.1:5197');
  await page.evaluate(async()=>{
   const {renderCloudSettings}=await import('/src/modules/configuracoes/cloud-view.js');document.body.replaceChildren();
   renderCloudSettings(document.body,{subscribe(fn){fn({phase:'conflict',email:'teste@example.com',namespace:'isolado',build:'candidata',verifiedRevision:null});return()=>{};},inspectConflicts:async()=>({revision:1,conflicts:[{collection:'budgets',key:'orc_004',reason:'duplicate-document-number',records:[{id:'abimael',cliente:'Abimael',total:839.29},{id:'abimaer',cliente:'Abimaer',total:1160}]},{collection:'budgets',key:'orc_007',reason:'duplicate-document-number',records:[{id:'g75',cliente:'Rodrigo G75',total:757.14},{id:'pc',cliente:'Rodrigo PC',total:1060}]}]}),resolveConflicts:async(_review,choices)=>{window.applied=choices;}});
  });
  await page.getByRole('button',{name:'Comparar alterações em conflito',exact:true}).click();
  const selects=page.locator('.cloud-copies select');await selects.nth(0).selectOption('keep-all');await selects.nth(1).selectOption('retain:g75');
  page.on('dialog',d=>d.accept());await page.getByRole('button',{name:'Aplicar escolhas e preservar cópia anterior',exact:true}).click();
  assert.deepEqual(await page.evaluate(()=>window.applied),{'budgets/orc_004':'keep-all','budgets/orc_007':'retain:g75'});
  console.log(`PASS interface ${viewport.width}x${viewport.height}: escolhas identificadas e enviadas`);await page.close();
 }
}finally{await browser.close();server.kill();}
