import { renderPartsCatalog } from '../orcamento/parts-catalog.js';
import { preparePhoto } from '../documentos/local-photo.js';
import { formatBRL } from '../../core/money.js';
import { el, button, labeledField, setFeedback } from '../../ui/dom.js';

import {STOCK_CATEGORIES,UNITS} from './stock-options.js';

function input(type='text') { const x=el('input','mod-input'); x.type=type; return x; }
function option(value,label){const x=el('option','',label);x.value=value;return x;}

export function renderEstoqueView(root, { service, partsCatalog, onChanged = () => {} }) {
  root.replaceChildren();
  let editingId = null,editingSnapshot=null,photoData='',preparingPhoto=false,savingMaterial=false;
  const page=el('section','simple-module');
  const head=el('div','module-toolbar'); const titles=el('div'); titles.append(el('h1','module-title','Estoque'),el('p','module-subtitle','Materiais e peças da oficina. O catálogo e os saldos são compartilhados com o Orçamento.'));
  const headActions=el('div','module-toolbar-actions'); const loadDefaults=button(`Carregar lista padrão (${service.defaultCount})`,'btn'); headActions.append(loadDefaults); head.append(titles,headActions);
  const feedback=el('div','module-feedback'); feedback.hidden=true;
  const body=el('div','module-body');
  const metrics=el('div','module-metrics');
  const mTotal=metric('Itens'); const mLow=metric('Baixo estoque'); const mZero=metric('Zerados'); const mValue=metric('Valor estimado'); metrics.append(mTotal.card,mLow.card,mZero.card,mValue.card);

  const controls=el('section','module-card'); controls.append(el('h2','', 'Pesquisar e filtrar'));
  const filters=el('div','module-form-row'); const search=input(); search.placeholder='Buscar material, categoria ou fornecedor'; const filter=el('select','mod-input'); filter.append(option('todos','Todos'),option('baixo','Baixo estoque'),option('zero','Zerados'));
  filters.append(labeledField('Busca',search),labeledField('Status',filter)); controls.append(filters);

  const editor=el('section','module-card'); const editorTitle=el('h2','', 'Cadastrar material'); editor.append(editorTitle);
  const form=el('form','stock-form');
  const name=input(); name.required=true; const category=el('select','mod-input'); Object.entries(STOCK_CATEGORIES).forEach(([v,l])=>category.append(option(v,l)));
  const unit=el('select','mod-input'); UNITS.forEach(v=>unit.append(option(v,v)));
  const qty=input('number'); qty.min='0';qty.step='0.01';qty.value='0'; const cost=input('number');cost.min='0';cost.step='0.01';cost.value='0'; const min=input('number');min.min='0';min.step='0.01';min.value='1'; const supplier=input();
  const formGrid=el('div','stock-form-grid'); formGrid.append(labeledField('Material',name),labeledField('Categoria',category),labeledField('Unidade',unit),labeledField('Quantidade',qty),labeledField('Custo unitário',cost),labeledField('Estoque mínimo',min),labeledField('Fornecedor',supplier));
  const photo=input('file');photo.accept='image/jpeg,image/png';const preview=el('img','stock-material-photo');preview.alt='Foto do material';preview.hidden=true;const removePhoto=button('Remover foto do material','btn');removePhoto.hidden=true;const photoArea=el('div','stock-material-photo-field');photoArea.append(labeledField('Foto do material (JPEG/PNG)',photo),preview,removePhoto);formGrid.append(photoArea);
  function showPhoto(){preview.hidden=!photoData;removePhoto.hidden=!photoData;if(photoData)preview.src=photoData;else preview.removeAttribute('src');}
  removePhoto.addEventListener('click',()=>{photoData='';photo.value='';showPhoto();});
  photo.addEventListener('change',async()=>{if(!photo.files[0])return;preparingPhoto=true;save.disabled=true;removePhoto.disabled=true;try{const prepared=await preparePhoto(photo.files[0]);if(prepared.length>2500000)throw Error('Foto muito grande após compressão. Escolha outra imagem.');photoData=prepared;showPhoto();}catch(e){photo.value='';setFeedback(feedback,e.message,'error');}finally{preparingPhoto=false;save.disabled=savingMaterial;removePhoto.disabled=false;}});
  const formActions=el('div','row-actions'); const save=button('Salvar material','btn btn-primary','submit'); const cancel=button('Cancelar edição','btn');cancel.hidden=true; formActions.append(save,cancel); form.append(formGrid,formActions); editor.append(form);

  const listCard=el('section','module-card'); const listHead=el('div','module-card-head'); const listCount=el('span','muted-small'); listHead.append(el('h2','','Itens do estoque'),listCount); const list=el('div','stock-list'); listCard.append(listHead,list);
  const sections=el('section','stock-areas');
  const materialsArea=el('article','module-card'),partsArea=el('article','module-card');
  const materialButton=button('Abrir Materiais','btn btn-primary'),partsButton=button('Peças Usadas e Recuperadas','btn btn-primary');
  materialsArea.append(el('h2','','Materiais'),el('p','muted-small','Consultar saldo, cadastrar, editar todos os campos e excluir materiais sem baixa vinculada.'),materialButton);
  partsArea.append(el('h2','','Peças Usadas e Recuperadas'),el('p','muted-small','Catálogo com fotos, aplicação, condição, valor e unidades. Cadastro, edição e exclusão manual protegida.'),partsButton);
  sections.append(materialsArea,partsArea);
  const materialsWindow=el('dialog','budget-stock-dialog stock-materials-window');materialsWindow.setAttribute('aria-label','Gerenciar Materiais');
  const materialsHead=el('header','module-card-head');const closeMaterials=button('Fechar Materiais','btn');materialsHead.append(el('h2','','Materiais'),closeMaterials);
  const materialsBody=el('div','module-body');materialsBody.append(metrics,controls,editor,listCard);materialsWindow.append(materialsHead,headActions,feedback,materialsBody);
  closeMaterials.addEventListener('click',()=>{if(!preparingPhoto&&!savingMaterial)materialsWindow.close();});materialsWindow.addEventListener('cancel',e=>{if(preparingPhoto||savingMaterial)e.preventDefault();});materialButton.addEventListener('click',async()=>{try{await refresh();materialsWindow.showModal();}catch(e){setFeedback(feedback,e.message,'error');}});
  const catalog=partsCatalog?renderPartsCatalog(page,{service:partsCatalog,onChanged}):null;partsButton.disabled=!catalog;
  partsButton.addEventListener('click',()=>catalog.open().catch(e=>setFeedback(feedback,e.message,'error')));
  body.append(sections);page.append(head,body,materialsWindow);root.append(page);

  function metric(label){const card=el('article','module-metric');const value=el('strong','module-metric-value','0');card.append(el('span','module-metric-label',label),value);return{card,value};}
  function resetForm(){editingSnapshot=null;photoData='';photo.value='';showPhoto();editingId=null;editorTitle.textContent='Cadastrar material';save.textContent='Salvar material';cancel.hidden=true;name.value='';category.value='outros';unit.value='Un';qty.value='0';cost.value='0';min.value='1';supplier.value='';}
  async function changed(message){setFeedback(feedback,message,'ok');resetForm();await refresh();await onChanged();}
  async function edit(row){if(preparingPhoto||savingMaterial)return;row=await service.get(row.id);if(!row){setFeedback(feedback,'Material não encontrado.','error');return;}editingSnapshot=structuredClone(row);photoData=row.foto||'';photo.value='';showPhoto();editingId=row.id;editorTitle.textContent='Editar material';save.textContent='Salvar alterações';cancel.hidden=false;name.value=row.nome||row.name||'';category.value=row.cat||row.category||'outros';unit.value=row.unid||'Un';qty.value=row.qty??0;cost.value=row.custo??row.cost??row.unit??0;min.value=row.minimo??row.minQty??1;supplier.value=row.forn||'';editor.scrollIntoView({behavior:'smooth',block:'start'});}
  async function refresh(){
    const [summary,rows]=await Promise.all([service.summary(),service.list({search:search.value,filter:filter.value})]);
    mTotal.value.textContent=summary.total;mLow.value.textContent=summary.low;mZero.value.textContent=summary.zero;mValue.value.textContent=formatBRL(summary.value);listCount.textContent=`${rows.length} item(ns)`;list.replaceChildren();
    if(!rows.length){list.append(el('p','empty-state','Nenhum material corresponde ao filtro.'));return;}
    for(const row of rows){const card=el('article','stock-row');const info=el('div','stock-info');const status=row.qty<=0?'zerado':row.qty<=row.minimo?'baixo':'ok';if(row.foto){const thumbnail=el('img','stock-material-photo');thumbnail.src=row.foto;thumbnail.alt=`Foto de ${row.nome}`;info.append(thumbnail);}info.append(el('strong','',row.nome),el('span','muted-small',`${STOCK_CATEGORIES[row.cat]||row.cat} · ${row.forn||'sem fornecedor'} · mínimo ${row.minimo} ${row.unid}`));const quantities=el('div','stock-qty');quantities.append(el('strong',`stock-status ${status}`,`${row.qty} ${row.unid}`),el('span','muted-small',formatBRL(row.custo)+' / un.'));
      const actions=el('div','row-actions'); const minus=button('−','btn btn-small');const plus=button('+','btn btn-small');const editBtn=button('Editar','btn btn-small');const del=button('Excluir','btn btn-small btn-danger');
      minus.addEventListener('click',async()=>{if(preparingPhoto||savingMaterial)return;try{await service.adjustQuantity(row.id,-1);await changed('Quantidade atualizada.');}catch(e){setFeedback(feedback,e.message,'error');}});plus.addEventListener('click',async()=>{if(preparingPhoto||savingMaterial)return;try{await service.adjustQuantity(row.id,1);await changed('Quantidade atualizada.');}catch(e){setFeedback(feedback,e.message,'error');}});editBtn.addEventListener('click',()=>edit(row));del.addEventListener('click',async()=>{if(preparingPhoto||savingMaterial)return;if(!window.confirm(`Excluir "${row.nome}" do estoque? Uma cópia preventiva será criada.`))return;try{await service.remove(row.id);await changed('Material removido.');}catch(e){setFeedback(feedback,e.message,'error');}});actions.append(minus,plus,editBtn,del);card.append(info,quantities,actions);list.append(card);}
  }
  form.addEventListener('submit',async event=>{event.preventDefault();if(preparingPhoto||savingMaterial)return;savingMaterial=true;save.disabled=true;const payload={nome:name.value,cat:category.value,unid:unit.value,qty:qty.value,custo:cost.value,minimo:min.value,forn:supplier.value,foto:photoData};try{if(editingId==null)await service.create(payload);else await service.update(editingId,payload,{expected:editingSnapshot});await changed(editingId==null?'Material cadastrado.':'Material atualizado.');}catch(e){setFeedback(feedback,e.message,'error');}finally{savingMaterial=false;save.disabled=preparingPhoto;}});
  cancel.addEventListener('click',()=>{if(!preparingPhoto&&!savingMaterial)resetForm();});search.addEventListener('input',()=>refresh());filter.addEventListener('change',()=>refresh());loadDefaults.addEventListener('click',async()=>{if(preparingPhoto||savingMaterial)return;if(!window.confirm('Adicionar os materiais padrão preservando todos os itens atuais? Nada será carregado automaticamente.'))return;try{const r=await service.loadDefaultList();await changed(r.added?`${r.added} materiais padrão adicionados.`:'Todos os materiais padrão já estavam presentes.');}catch(e){setFeedback(feedback,e.message,'error');}});
  resetForm();refresh();return{refresh};
}
