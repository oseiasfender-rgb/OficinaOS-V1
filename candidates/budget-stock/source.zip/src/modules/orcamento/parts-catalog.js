import {planPartsCatalogMutation} from './parts-catalog-mutation.js';
import { safeText } from '../../core/validators.js';
import { parseBRL } from '../../core/money.js';
import { el, button, labeledField } from '../../ui/dom.js';
import { preparePhoto } from '../documentos/local-photo.js';
const KEY='fp_pecas_rec';
export function createPartsCatalogService(repositories){
 const repo=repositories.settings;
 async function list(){const row=await repo.get(KEY);return Array.isArray(row?.value)?structuredClone(row.value):[];}
 async function mutate(operation){
  if(repositories.mutatePartsCatalog)return repositories.mutatePartsCatalog(operation);
  const result=planPartsCatalogMutation(await list(),operation);
  if(result.changed){await repo.put({id:KEY,value:result.rows,updatedAt:operation.at});if(result.backup)await repositories.deletionBackups.put(result.backup);}
  return result.row;
 }
 return {
  list,
  async deleted(){return (await repositories.deletionBackups.list()).filter(b=>b.entityType==='partsCatalog');},
  async restore(backupId){const b=await repositories.deletionBackups.get(backupId);if(b?.entityType!=='partsCatalog')throw Error('Cópia inválida.');return mutate({action:'restore',row:structuredClone(b.payload),at:new Date().toISOString()});},
  async put(input,{expected}={}){
   input={...expected,...input};
   const name=safeText(input.nome??input.name,180);if(!name)throw Error('Nome da peça é obrigatório.');
   const value=parseBRL(input.valor??input.value);if(value<0)throw Error('Valor inválido.');
   const photo=String(input.foto??'');if(photo&&(!/^data:image\/(jpeg|png);base64,[A-Za-z0-9+/=]+$/.test(photo)||photo.length>2500000))throw Error('Foto inválida.');
   const qtd=Number(input.qtd??expected?.qtd??0);if(!Number.isFinite(qtd)||qtd<0)throw Error('Quantidade disponível inválida.');
   const at=new Date().toISOString(),row={...input,id:input.id??`pec_${Date.now()}_${Math.random().toString(36).slice(2,7)}`,nome:name,categoria:safeText(input.categoria,80),aplicacao:safeText(input.aplicacao,160),condicao:['Boa','Regular','Ruim'].includes(input.condicao)?input.condicao:'Boa',valor:value,qtd,foto:photo,updatedAt:at};
   return mutate({action:'put',row,expected,at});
  },
  async remove(id,{expected}={}){const at=new Date().toISOString();return mutate({action:'delete',row:{id},expected,at,backup:{id:`parts_${id}_${crypto.randomUUID()}`,at,entityType:'partsCatalog',reason:'delete'}});}
 };
}
export function renderPartsCatalog(host,{service,onSelect,onChanged}){
 const details=el('dialog','budget-stock-dialog budget-stock-picker parts-catalog');details.setAttribute('aria-label','Escolher peça do catálogo');const editor=el('dialog','budget-stock-dialog parts-catalog-editor');editor.setAttribute('aria-label','Cadastrar ou editar peça');const editorTitle=el('h2','','Cadastrar peça');const feedback=el('p','status-line');const form=el('form','budget-grid');let editing=null,photoData='',saving=false,preparing=false;
 function field(name,type='text'){const input=el('input','mod-input');input.type=type;form.append(labeledField(name,input));return input;}
 const name=field('Nome da peça'),category=field('Categoria'),application=field('Aplicação / veículo'),condition=el('select','mod-input');for(const c of ['Boa','Regular','Ruim']){const o=el('option','',c);o.value=c;condition.append(o);}form.append(labeledField('Condição',condition));const qty=field('Quantidade disponível da peça (unidades)','number');qty.min='0';qty.required=true;qty.placeholder='Ex.: 10';qty.value='';const value=field('Valor por peça');const photo=field('Foto da peça','file');photo.accept='image/jpeg,image/png';photo.addEventListener('change',async()=>{preparing=true;save.disabled=true;try{photoData=photo.files[0]?await preparePhoto(photo.files[0]):'';}catch(e){feedback.textContent=e.message;}finally{preparing=false;save.disabled=saving;}});const save=button('Salvar peça no catálogo','btn','submit'),cancel=button('Cancelar edição','btn'),removePhoto=button('Remover foto do cadastro','btn');removePhoto.addEventListener('click',()=>{photoData='';photo.value='';feedback.textContent='Foto removida do rascunho. Salve a peça para confirmar.';});let initialForm='';const formState=()=>JSON.stringify([...form.querySelectorAll('input,select')].map(c=>c.type==='file'?photoData:c.value));function reset(){editing=null;photoData='';form.reset();qty.value='';initialForm=formState();}function closeEditor(){if(saving||preparing)return;if(formState()!==initialForm&&!window.confirm('Descartar as alterações não salvas desta peça?'))return;editor.close();reset();refresh().catch(e=>{feedback.textContent=e.message;});}cancel.addEventListener('click',closeEditor);form.append(save,cancel,removePhoto);
 const search=el('input','mod-input');search.placeholder='Buscar peça ou aplicação';search.dataset.syncReadOnly='true';search.setAttribute('aria-label','Buscar peça no catálogo');const filter=el('select','mod-input');for(const c of ['Todas','Boa','Regular','Ruim']){const o=el('option','',c);o.value=c;filter.append(o);}filter.setAttribute('aria-label','Filtrar condição da peça');filter.dataset.syncReadOnly='true';const list=el('div','stack-list stock-picker-list');
 let refreshVersion=0;async function refresh(){const version=++refreshVersion;const q=search.value.toLocaleLowerCase('pt-BR'),rows=(await service.list()).filter(p=>(filter.value==='Todas'||p.condicao===filter.value)&&[p.nome,p.aplicacao,p.categoria].some(v=>String(v||'').toLocaleLowerCase('pt-BR').includes(q)));const all=await service.list(),deleted=await service.deleted();if(version!==refreshVersion)return;count.textContent=`${all.length} tipo(s) de peça · ${all.reduce((n,r)=>n+Number(r.qtd||0),0).toLocaleString('pt-BR')} unidades disponíveis`;list.replaceChildren();for(const backup of deleted){if(all.some(r=>String(r.id)===String(backup.payload.id)))continue;const restore=button(`Restaurar peça — ${backup.payload.nome}`,'btn btn-small');restore.addEventListener('click',async()=>{try{await service.restore(backup.id);await refresh();onChanged?.();}catch(e){feedback.textContent=e.message;}});list.append(restore);}if(!rows.length)list.append(el('p','empty-state','Nenhuma peça cadastrada para este filtro.'));for(const row of rows){const item=el('article','list-row');const info=el('div','list-main');if(/^data:image\/(jpeg|png);base64,[A-Za-z0-9+/=]+$/.test(row.foto||'')){const img=el('img','catalog-photo');img.src=row.foto;img.alt=row.nome;info.append(img);}info.append(el('strong','',row.nome),el('span','muted',`${row.condicao} · ${row.aplicacao||'Sem aplicação'} · ${Number(row.qtd??0).toLocaleString('pt-BR')} unidades disponíveis`));const actions=el('div','row-actions');const use=button('Usar no orçamento','btn btn-small');use.addEventListener('click',()=>{onSelect({id:`part_${Date.now()}`,catalogId:row.id,priceBasis:'unit',foto:row.foto||'',name:row.nome,category:row.categoria,application:row.aplicacao,condition:row.condicao,qty:1,value:row.valor});feedback.textContent='Peça incluída no orçamento; a baixa do catálogo ocorre ao salvar o orçamento.';});const edit=button('Editar peça','btn btn-small');edit.addEventListener('click',()=>{editing=structuredClone(row);name.value=row.nome;category.value=row.categoria||'';application.value=row.aplicacao||'';condition.value=row.condicao;qty.value=row.qtd??0;value.value=String(row.valor??0).replace('.',',');photoData=row.foto||'';editorTitle.textContent=`Editar peça — ${row.nome}`;initialForm=formState();editorFeedback.textContent='';if(!editor.open)editor.showModal();name.focus();});const del=button('Excluir peça','btn btn-small btn-danger');del.addEventListener('click',async()=>{if(!window.confirm(`Excluir ${row.nome} do catálogo?`))return;try{await service.remove(row.id,{expected:row});await refresh();onChanged?.();}catch(e){feedback.textContent=e.message;}});actions.append(use,edit,del);item.append(info,actions);list.append(item);}}
 form.addEventListener('submit',async e=>{e.preventDefault();if(saving||preparing)return;saving=true;save.disabled=true;try{if(editing&&Number(qty.value)!==Number(editing.qtd)&&!window.confirm(`Ajustar manualmente o saldo de ${editing.nome} de ${editing.qtd} para ${qty.value}? Este ajuste altera a quantidade disponível no catálogo.`))return;await service.put({...editing,nome:name.value,categoria:category.value,aplicacao:application.value,condicao:condition.value,qtd:qty.value,valor:value.value,foto:photoData},{expected:editing??undefined});reset();editor.close();feedback.textContent='Peça salva no catálogo.';await refresh();onChanged?.();}catch(e){feedback.textContent=e.message;}finally{saving=false;save.disabled=false;}});search.addEventListener('input',refresh);filter.addEventListener('change',refresh);
 const pickerHead=el('header','stock-picker-head'),title=el('div');title.append(el('h2','','Peças — escolher do catálogo'),el('p','muted-small','Escolha a peça. A baixa das unidades ocorre ao salvar o orçamento.'));
 const close=button('✕','btn stock-dialog-close');close.setAttribute('aria-label','Fechar catálogo de peças');pickerHead.append(title,search,close);
 const filters=el('div','parts-picker-filters');filters.append(labeledField('Condição',filter));
 const count=el('p','muted-small parts-picker-count'),foot=el('footer','stock-picker-footer'),create=button('＋ Cadastrar peça','btn btn-primary'),finish=button('Fechar','btn');foot.append(create,finish);
 details.append(pickerHead,filters,count,list,feedback,foot);
 const editorHead=el('header','stock-edit-head'),editorClose=button('✕','btn stock-dialog-close');editorClose.setAttribute('aria-label','Fechar edição da peça');editorHead.append(editorTitle,editorClose);
 const editorFeedback=el('p','status-line');editor.append(editorHead,el('p','muted-small','Um cadastro representa um tipo de peça. Informe a quantidade de unidades disponíveis.'),form,editorFeedback);
 // Mensagens de gravação precisam permanecer visíveis no diálogo do editor.
 const showMessage=()=>{editorFeedback.textContent=feedback.textContent;};
 new MutationObserver(showMessage).observe(feedback,{childList:true,characterData:true,subtree:true});
 editor.addEventListener('cancel',e=>{e.preventDefault();closeEditor();});editorClose.addEventListener('click',closeEditor);
 create.addEventListener('click',()=>{reset();editorTitle.textContent='Cadastrar peça';editorFeedback.textContent='';if(!editor.open)editor.showModal();name.focus();});
 close.addEventListener('click',()=>details.close());finish.addEventListener('click',()=>details.close());
 host.append(details,editor);
 async function open(condition='Todas'){filter.value=condition;search.value='';await refresh();const rows=await service.list();count.textContent=`${rows.length} tipo(s) de peça · ${rows.reduce((n,r)=>n+Number(r.qtd||0),0).toLocaleString('pt-BR')} unidades disponíveis`;if(!details.open)details.showModal();search.focus();}
 reset();return {refresh,open,filter:open};
}
