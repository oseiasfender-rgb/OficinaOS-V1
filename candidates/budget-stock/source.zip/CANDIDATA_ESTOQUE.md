# Candidata Estoque r1 — situação em 04/11/2026

Revisão corrente: estoque-20261104-r1-fix8. Resultado atual: 347 testes unitários; interface/documentos/OS/backup/offline e regressões das proteções revistas. Registros abaixo por correção são históricos, com suas contagens da época.

TESTES SOMENTE. Banco local oficinaos_homologacao_estoque_20261028 e nuvem homologacao_estoque_v1. Sessão, metadados e saldos separados da r5 e produção. Inicia vazia e pausada, sem importação automática. Não substitui aplicativos instalados.

Baixa ao salvar orçamento: material selecionado do Estoque, peça selecionada do catálogo. Editar ajusta diferença; excluir linha devolve somente quantidade debitada; salvar novamente não repete débito. Saldo insuficiente reverte a gravação completa. Itens manuais sem vínculo não baixam automaticamente. Orçamentos antigos importados não têm baixa retroativa. Arquivar ou lixeira não devolvem automaticamente.

A OS aproveita quantidade já debitada pelo orçamento e baixa só o excedente. Devolução não reabre crédito reutilizável. Revisão antes da OS transfere alocação sem nova baixa. Ajuste de orçamento já vinculado à execução exige registro de consumo/devolução na OS. Operações concorrentes de saldo são bloqueadas para análise, não reconciliadas automaticamente.

Validado localmente: 323 testes; build; Chromium 1366x768 e 412x915 com IndexedDB real, serviços reais e dados de teste. Inclusão sem salvar preserva saldo; salvar, repetir, editar, insuficiência, duplicação e fotos conferidos. Não equivale à validação física PC/Android.

## Teste nos aparelhos

Abra a candidata Estoque r1. Não importe os backups da r5 para este primeiro teste. No PC, cadastre um material com saldo 10 e custo informado e uma peça com saldo 5 e foto; crie orçamento de teste incluindo 2 unidades do material e 1 peça. Salve e confira saldos 8 e 4. Salve novamente: devem continuar 8 e 4. Aumente material a 3 e salve: saldo 7. Antes de qualquer edição no Android, envie a cópia inicial do PC pelo botão Usar este aparelho como origem; no Android, com a mesma conta e ambiente, Receber dados da nuvem. Confira mesmo orçamento, foto, saldos e revisão. Faça as edições em um aparelho por vez e sincronize antes de passar ao outro. Quantidades acima do saldo devem bloquear orçamento e baixa integralmente.

## Supabase

A migração adiciona somente o ambiente homologacao_estoque_v1 à lista permitida. Mantém auth.uid(), isolamento por dono, RLS, execução anônima revogada, limites de 8 MiB/64 MiB por conta e ambiente e todos os backups. RPC validada em transação revertida; novo ambiente permaneceu sem registros. Avisos de segurança pré-existentes não foram introduzidos: RPC security definer autenticada intencional e proteção de senhas vazadas desativada. Referências: https://supabase.com/docs/guides/database/database-linter?lint=0029_authenticated_security_definer_function_executable e https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection .


## Correção 1 — editor do catálogo e proteção do saldo (28/10/2026)

Build estoque-20261028-r1-fix1, mesmo banco local e mesmo ambiente homologacao_estoque_v1. Não modifica saldos existentes automaticamente.

Um backup enviado pelo usuário mostrava alocação de 5 Paralama no orçamento, baixas registradas e cadastro final com 10 disponíveis. Isso comprova divergência entre histórico e cadastro, mas não prova se houve reposição física ou qual ação do usuário produziu o saldo final. A análise identificou e reproduziu um caminho de sobrescrita: editor de catálogo aberto antes da baixa pode salvar a quantidade antiga depois dela.

Correção: atualização de peça e baixa agora disputam a mesma transação de settings. Salvar ou excluir cadastro exige snapshot atual da peça; edições antigas são rejeitadas sem alterar saldo/foto. Excluir peça com alocação de orçamento é bloqueado. Ajuste manual de quantidade exige confirmação explícita na interface e registra antes/depois em settings. Inclusão de outra peça não sobrescreve saldo de cadastros existentes. Todos os backups e fotos são preservados.

Validação: 326 testes passaram, build e interface desktop/mobile passaram com o fluxo completo pricingVersion 2. Novo teste abre editor, baixa pelo orçamento, tenta salvar editor antigo, verifica rejeição e saldo preservado. Replay isolado do backup reproduz a proteção e verifica arquivo original intacto. Backup, fotos e dados pessoais não foram incluídos no GitHub.

Conferência no aparelho: antes de editar, confira o build em Configurações. Reabra o catálogo; para testar a correção use um orçamento de teste com uma nova peça, saldo 10 e quantidade 5. Ao salvar orçamento, deve ficar 5. Salvar novamente deve manter 5. Não force nova baixa no orçamento anterior; o ledger já registra suas 5 unidades. O saldo atual do cadastro Paralama deve ser conciliado com a contagem real, sem inferência automática a partir de registros incompletos.


## Correção 2 — clareza de unidades e conferência do ciclo completo

Build estoque-20261028-r1-fix2, mesmo banco e ambiente. Campo Quantidade disponível da peça (unidades); novo cadastro não presume uma unidade. Indicadores de tipos de peças separados do total de unidades. Linhas mostram disponível/já baixado e avisam quando são avulsas sem baixa. Confirmação de salvar diferencia ajuste de estoque de salvamento sem nova baixa. Edição parcial do cadastro preserva quantidade/foto e envio duplicado do formulário é bloqueado. Materiais com baixa de orçamento também são protegidos contra exclusão, troca de unidade e edição obsoleta do saldo.

Registro de fechamento: ENCERRAMENTO_ORCAMENTO_20261028.md. Testes ampliados incluem devolução ao excluir linha, reabertura na aplicação completa, novo salvamento sem débito repetido, peça avulsa sem movimentação e ausência de rolagem horizontal. Documento comercial e consumo da OS também verificados. Homologação física de saldos e revisão entre PC/G75 continua pendente; produção não foi liberada.

## Correção 3 — janela de Peças semelhante à de Materiais

Build histórico estoque-20261028-r1-fix3. O botão Escolher do catálogo e os indicadores por condição abrem uma janela modal de Peças com busca, filtro, fotos, unidades disponíveis e ações Usar no orçamento, Editar e Excluir. Cadastro/edição usam uma segunda janela, sem expandir formulário no orçamento. Fechar e Escape disponíveis; alterações não salvas no editor pedem confirmação para descartar. Durante a preparação da foto e gravação, o envio repetido é bloqueado. Busca/filtro são consultas e não marcam o orçamento como editado para a sincronização.

Mantidos IDs, fotos, unidades, proteção contra edição obsoleta e baixa somente ao salvar o orçamento. Mesmo banco local, conta e ambiente, sem alteração automática de dados ou publicação na produção.

Validação: 329 testes, build e testes de interface desktop/mobile passaram. Janela testada com busca, filtro, cadastro com foto PNG válida, verificação de decodificação das fotos, edição obsoleta, descarte/cancelamento, Escape e ausência de rolagem horizontal. Validações anteriores de saldo e documentos permanecem no workflow.

## Catálogo compartilhado na aba Estoque — correção 4
Estoque oferece acesso à janela Peças Usadas e Recuperadas. Reutiliza o mesmo serviço, registro, IDs, fotos, quantidade disponível e proteção de concorrência do Orçamento; não copia nem migra dados. No Estoque a janela gerencia cadastro, edição, reposição e exclusão protegida; apenas no Orçamento oferece Usar no orçamento. A baixa permanece na gravação do orçamento. Validação em navegador desktop e Android simulado: editar saldo de uma peça pelo Estoque aparece no Orçamento, foto preservada e sem baixa adicional.

## Espaços separados — correção 5
A aba Estoque apresenta dois cartões: Materiais e Peças Usadas e Recuperadas, abrindo janelas distintas. Materiais mantém busca, indicadores, cadastro e edição de nome, categoria, unidade, saldo, custo, mínimo e fornecedor; Peças mantém nome, categoria, aplicação, condição, unidades, valor e foto. Exclusão manual de itens livres com cópia preventiva; itens com baixa vinculada permanecem protegidos, assim como troca de unidade em material consumido. Não há exclusão em cascata de orçamentos/OS. Mesmos dados e serviços, sem migração de saldo.

## Exclusão de cópia de peça — correção 6
Cada ação Restaurar peça tem Excluir cópia com confirmação. A cópia atual é substituída por marcador descartado sem payload/foto, evitando reaparecer como cópia restaurável. Não altera peças ativas, saldos ou fotos nos orçamentos. Backups JSON já exportados e versões históricas na nuvem não são apagados. Validação inclui cancelar e confirmar exclusão na interface desktop/mobile.

## Foto de materiais — correção 7
Cadastro e edição de material aceitam JPEG/PNG com compressão local, prévia, miniatura na lista e remoção explícita. Foto gravada em stock.foto, no mesmo registro do saldo; atualizações parciais e baixa preservam o campo. Backup e nuvem usam o registro completo existente. Salvar é bloqueado enquanto prepara foto/grava; erros mantêm a foto anterior. Estoque continua separado do Orçamento, com catálogo compartilhado.

## Conferência de backup/offline — 03/11/2026
Sem mudança funcional ou de build. Exportação/importação e repetição entre perfis isolados preservam fotos de material/peça/etapa, IDs, saldos, alocação e registros de baixa. Reabertura, salvamento sem nova baixa e edição offline conferidos no build local em 1366×768 e 412×915. Script check-budget-backup-offline.mjs incluído no CI. Homologação física PC/G75 e auditoria final seguem pendentes; consulte ENCERRAMENTO_ORCAMENTO_20261028.md.

## Correção 8 — proteções da revisão transversal (04/11/2026)
Build estoque-20261104-r1-fix8. Mesmo banco, conta e ambiente; sem migração de saldos. Materiais conferem snapshot capturado ao abrir a edição nas duas telas; cadastro/saldo alterados rejeitam formulário antigo. Exclusão de cliente verifica vínculos em transação com os registros relacionados e só exclui cliente livre com cópia preventiva. Renomeação de Meta passa a ser atômica, inclusive diante de falha após inclusão do novo nome. Configurações preserva rascunho ao trocar de aba, oferece descarte confirmado, avisa antes de sair/recarregar e impede aplicação remota durante edição/preparação/gravação. Manual esclarece baixa ao salvar, avulsos, fotos, offline e sincronização. Sem CSV, nova aba, migração de dados ou IA externa. Detalhes: CORRECOES_ABAS_20261104.md. Homologação física e auditoria final continuam pendentes.
